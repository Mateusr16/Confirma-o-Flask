from flask import Flask

from . import db
from .registro import configurar_log


def create_app() -> Flask:
    log = configurar_log()
    app = Flask(__name__, static_folder="static")
    app.json.ensure_ascii = False

    aplicadas = db.migrar()
    if aplicadas:
        log.info("Migrações aplicadas: %s", aplicadas)

    from .rotas.webhooks import bp
    app.register_blueprint(bp)
    return app

"""Mesmos caminhos do n8n (/webhook/<path>), para o painel e o DigiSac não mudarem nada."""
import logging
import threading
import time

from flask import Blueprint, jsonify, request

from .. import db
from ..fluxos import HANDLERS
from ..registro import alertar_erro

log = logging.getLogger("central")
bp = Blueprint("webhooks", __name__)

# path -> métodos aceitos (copiado da v28)
WEBHOOKS = {
    "central-lider": ["GET"],                 # Frontend (painel)
    "central-lider-pendencias": ["GET"],      # API Pendências
    "status-fluxo-lider": ["GET"],            # Status do disparo
    "disparar-fluxo-lider": ["POST"],         # Disparo pelo painel
    "central-lider-revisao": ["POST"],        # Decisão de Envio
    "central-lider-resolver": ["POST"],       # Resolver Pendência
    "central-lider-consultor": ["POST"],      # Consultor (Chat)
    "central-lider-recomecar": ["POST"],      # Recomeçar Pedido
    "digisac-resposta": ["POST"],             # Resposta do cliente (DigiSac)
}

# Estes respondem 200 na hora e processam em segundo plano
# (o DigiSac não pode ficar esperando a IA e a intranet).
ASSINCRONOS = {"digisac-resposta"}


def _dados_requisicao() -> dict:
    dados = dict(request.args)
    if request.is_json:
        corpo = request.get_json(silent=True)
        if isinstance(corpo, dict):
            dados.update(corpo)
        elif corpo is not None:
            dados["body"] = corpo
    elif request.form:
        dados.update(request.form.to_dict())
    return dados


def _rodar(path: str, dados: dict, req_info: dict):
    inicio = db.agora_iso()
    handler = HANDLERS.get(path)
    if handler is None:
        db.registrar_execucao(path, "nao_migrado", {"dados": dados}, inicio)
        return {"erro": f"Gatilho '{path}' ainda não migrado para o Flask"}, 501
    try:
        resp, codigo = handler(dados, req_info)
        db.registrar_execucao(path, "ok", {"dados": dados}, inicio)
        return resp, codigo
    except Exception as exc:  # noqa: BLE001
        db.registrar_execucao(path, "erro", {"dados": dados}, inicio, erro=repr(exc))
        alertar_erro(f"webhook {path}", exc, {"dados": dados})
        return {"erro": "Falha interna", "detalhe": str(exc)}, 500


def _criar_rota(path: str, metodos: list[str]):
    def view():
        dados = _dados_requisicao()
        req_info = {"metodo": request.method, "headers": dict(request.headers),
                    "recebido_em": time.time()}
        if path in ASSINCRONOS:
            threading.Thread(target=_rodar, args=(path, dados, req_info),
                             name=f"wh-{path}", daemon=True).start()
            return jsonify({"recebido": True}), 200
        resp, codigo = _rodar(path, dados, req_info)
        if isinstance(resp, (dict, list)):
            return jsonify(resp), codigo
        return resp, codigo

    view.__name__ = "wh_" + path.replace("-", "_")
    bp.add_url_rule(f"/webhook/{path}", view_func=view, methods=metodos + ["OPTIONS"])


for _p, _m in WEBHOOKS.items():
    _criar_rota(_p, _m)


@bp.after_app_request
def _cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


@bp.get("/api/saude")
def saude():
    from ..config import Config
    pendentes = [p for p in WEBHOOKS if p not in HANDLERS]
    return jsonify({
        "ok": True,
        "modo_teste": Config.MODO_TESTE,
        "agendador_ativo": Config.AGENDADOR_ATIVO,
        "gatilhos_migrados": sorted(p for p in WEBHOOKS if p in HANDLERS),
        "gatilhos_pendentes": pendentes,
    })

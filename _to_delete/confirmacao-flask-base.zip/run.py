"""Inicia o servidor da Central Líder.

    python run.py            -> servidor de produção (waitress) + agendador
    python run.py --debug    -> servidor de desenvolvimento do Flask
"""
import logging
import sys

from app import create_app
from app import agendador
from app.config import Config

app = create_app()

if __name__ == "__main__":
    log = logging.getLogger("central")
    log.info("Central Líder | http://%s:%s | MODO_TESTE=%s | AGENDADOR=%s",
             Config.HOST, Config.PORT, Config.MODO_TESTE, Config.AGENDADOR_ATIVO)
    agendador.iniciar()
    if "--debug" in sys.argv:
        app.run(host=Config.HOST, port=Config.PORT, debug=True, use_reloader=False)
    else:
        from waitress import serve
        serve(app, host=Config.HOST, port=Config.PORT, threads=8)

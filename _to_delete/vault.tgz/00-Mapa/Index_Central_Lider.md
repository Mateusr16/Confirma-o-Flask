---
projeto: Central Líder
fluxos: ["Central Líder: v26"]
arquivo_fluxo: Claude outputs/Fluxo_Central_Lider__12-11_v26_TRAVA_REGISTRO_UNICO.json
atualizado: 2026-11-12
status: ativo
tags: [index, n8n, "central-lider"]
---
# Central Líder

**Objetivo:** confirmar com o cliente, pelo WhatsApp (DigiSac), a data de entrega dos pedidos da Líder. O fluxo lê os pedidos do dia, confere intranet, boleto e prazo, monta a mensagem, envia depois da revisão do consultor e trata a resposta do cliente (aceite, adiamento, dúvidas), atualizando intranet, planilha e data tables.

**Números da v26:** 468 nós · 18 gatilhos (9 webhooks, 6 agendamentos, 1 manual, 1 de erro, 1 ao iniciar o n8n) · 6 data tables + 1 planilha · 6 cadeias de IA com Gemini.

## Mapa

```mermaid
graph LR
  P1[Painel: disparar] --> E11[F1-1 Coleta e validação]
  E11 --> E12[F1-2 Boleto e prazo]
  E12 --> E13[F1-3 Histórico e mensagem]
  E13 --> RV[Painel: Revisão de envio]
  RV --> E14[F1-4 Liberação e envio]
  E14 --> DSG>DigiSac]
  DSG --> E21[F2-1 Respostas do cliente]
  E21 --> E22[F2-2 Dúvidas e consultor]
  E22 --> PC[Painel: Consultor]
  AG[Agendamentos] --> E23[F2-3 Automações agendadas]
  E23 --> DSG
  E12 --> RB{{Trava de boleto}}
  E12 --> ROU{{Outlet}}
  E13 --> RMU{{Mensagem única}}
  E23 --> RLE{{Lembrete 13h}}
  E14 --> RO{{Chamado ocupado}}
  PRC[Painel: Recomeçar] --> RRC{{Recomeço do pedido}}
  RRC --> RV
  RRC --> DSG
  E21 --> RA{{Adiamento e armazenagem}}
  VT[Varredura de respostas tardias] --> RT{{Resposta tardia}}
  VT --> DSG
  RT --> PT[Painel: Respostas tardias]
  E11 --> INT[(Intranet)]
  E12 --> INT
  E21 --> INT
  E12 --> ROT>Rotas OSRM]
  E21 --> IA>Gemini]
  E22 --> IA
  E13 --> AE[(AGUARDANDO_ENTREGA)]
  E14 --> AE
  E21 --> AE
  E23 --> AE
  E13 --> SC[(SEM_CONFIRMACAO_DIARIO)]
  E23 --> SC
  E21 --> MC[(MENSAGENS_CLIENTE)]
  E22 --> BC[(BASE_CONHECIMENTO)]
  E21 --> PL[(Planilha de confirmações)]
```

## Gatilhos
- [[Gatilho - Disparo pelo painel]]
- [[Gatilho - Execução manual]]
- [[Gatilho - Decisão de Envio]]
- [[Gatilho - Resolver Pendência]]
- [[Gatilho - API Pendências]]
- [[Gatilho - Frontend (painel)]]
- [[Gatilho - Status do disparo]]
- [[Gatilho - Resposta do cliente (DigiSac)]]
- [[Gatilho - Consultor (Chat)]]
- [[Gatilho - Encerramento de pendências]]
- [[Gatilho - Reenvio do template]]
- [[Gatilho - Varredura de vigilância]]
- [[Gatilho - Chamados ocupados]]
- [[Gatilho - Lembrete de confirmação (13h)]]
- [[Gatilho - Varredura de respostas tardias]]
- [[Gatilho - Recomeçar pedido]]
- [[Gatilho - Erro no fluxo]]

## Etapas
**Fluxo 1 – preparar e enviar:** [[F1-1 Coleta e validação]] → [[F1-2 Boleto e prazo]] → [[F1-3 Histórico e mensagem]] → [[F1-4 Liberação e envio]]
**Fluxo 2 – resposta do cliente:** [[F2-1 Respostas do cliente]] → [[F2-2 Dúvidas e consultor]] · [[F2-3 Automações agendadas]]

## Regras de negócio
- [[Regra - Limpeza diária]]
- [[Regra - Pedido cancelado ou entregue]]
- [[Regra - Planejados e data fictícia]]
- [[Regra - Trava de boleto e boleto 50%]]
- [[Regra - Prazo de entrega e distância]]
- [[Regra - Tipo de móvel por responsável]]
- [[Regra - Reincidência sem retorno]]
- [[Regra - Resposta tardia]]
- [[Regra - Chamado ocupado]]
- [[Regra - Edição da mensagem na Revisão]]
- [[Regra - Classificação da resposta do cliente]]
- [[Regra - Registro único do contato]]
- [[Regra - Adiamento e armazenagem]]
- [[Regra - Encerramento sem retorno]]
- [[Regra - Reenvio do template]]
- [[Regra - Vigilância e lembretes ao consultor]]
- [[Regra - Outlet]]
- [[Regra - Mensagem única por cliente]]
- [[Regra - Lembrete de confirmação (13h)]]
- [[Regra - Recomeço do pedido]]
- [[Regra - Anti-repetição de mensagens]]

## Dados e integrações
- [[AGUARDANDO_ENTREGA]]
- [[HISTORICO_PEDIDOS]]
- [[FLUXO_STATUS]]
- [[SEM_CONFIRMACAO_DIARIO]]
- [[MENSAGENS_CLIENTE]]
- [[BASE_CONHECIMENTO]]
- [[Planilha de confirmações]]
- [[Intranet Líder]]
- [[DigiSac]]
- [[Gemini (IA)]]
- [[E-mails de alerta]]
- [[Rotas (Nominatim e OSRM)]]

## Frontend
- [[Painel Central Líder]]
- [[Páginas salvas da intranet]]

## Versões
- [[v26 TRAVA_REGISTRO_UNICO]]
- [[v25 EMAIL_CONSULTOR_COMPLETO]]
- [[v24 VARREDURA_TARDIA]]
- [[v23 OCUPADO_SEM_RETORNO]]
- [[v21 ANTI_REPETICAO]]
- [[v20 RECOMECO_CONSULTA_CPF]]
- [[v18 RECOMECAR_PEDIDO]]
- [[v17 OUTLET_CONFIRMADO]]
- [[v16 TELA_PROGRESSO]]
- [[v15 VIDEO_PLANEJADOS]]
- [[v14 LEMBRETE_13H]]
- [[v13 OUTLET]]
- [[v12 MENSAGEM_UNICA]]
- [[v11 DASHBOARD_CONTAGEM]]
- [[v10 AVISO_ARMAZENAGEM]]
- [[v9 EDITAR_MENSAGEM]]
- [[v8 RESPOSTA_TARDIA]]
- [[v7 CHAMADO_OCUPADO]]
- [[v6 1A_CONFIRMACAO]]
- [[v5 TRAVA_BOLETO]]
- [[v4 HISTORICO_PEDIDOS]]
- [[Versões de 05-11]]

## Testes
- [[Teste - Reset do pedido 97680]]
- [[Testes registrados por versão]]

## Apoio
- [[Glossário de status]] · [[_Convencoes]]

## Arquivos do projeto (fora do vault)
- Fluxo atual: `Claude outputs/Fluxo_Central_Lider__12-11_v26_TRAVA_REGISTRO_UNICO.json`
- Manual do operador: `Manual_Operador_Automacao_Central_Lider.docx`
- Fluxograma: `Fluxograma_v9_09-11/`
- Diário de bordo e revisões: Projeto "N8N-Confirmação" no claude.ai

## Pendências abertas (do diário)
- v26: importar e publicar (substitui a v25); corrigir à mão o 2º registro do Guilherme (protocolo 23223218); teste real com o 97680 ("ok, mas faltou um item" e "ok" repetido depois de confirmar); registros anteriores à v26 não têm a marca.
- v25: importar e publicar (substitui a v24); no próximo dia com reincidência, conferir 1 e-mail por consultor com todos os pedidos.
- v24: importar e publicar (substitui a v23, que não chegou a ser importada); rodar a varredura para a Sarah (resposta de 11/11 às 21:01); na 1ª execução real, conferir o formato da resposta de `/api/v1/messages` no [[DigiSac]].
- v23: no 1º encerramento real, conferir planilha, resumo e se só os chamados na fila foram fechados.
- Contatos criados antes da v20 seguem com o nome antigo no [[DigiSac]] (sem CPF ou com CPF como "CNPJ").
- v21: envios ao Digisac ainda com nova tentativa; 4 respostas do caminho do responsável sem trava de saída ([[Regra - Anti-repetição de mensagens]]).
- Importar no n8n e fazer o teste real das versões v8 a v21 (v20: recomeçar o 11-210588 pela tela Consultas da IA, com aviso ao Rafi) (pedido de teste 97680; 11-209534 para o outlet; um cliente com 2 pedidos para a mensagem única).
- Cadastrar a regra de armazenagem na [[BASE_CONHECIMENTO]].
- O painel ainda não mostra quem recebeu o [[Regra - Lembrete de confirmação (13h)]].
- Conferir no 1º dia real quantos lembretes saíram e quantos responderam.
- O intervalo entre envios mudou de ~10 s para ~5 s na v13 e isso não está no diário de bordo.

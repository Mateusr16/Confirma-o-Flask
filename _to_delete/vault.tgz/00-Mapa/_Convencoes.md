---
projeto: Central Líder
atualizado: 2026-11-12
tags: [convencoes]
---
# Convenções do projeto

- **Fluxo:** um único workflow n8n (Central Líder), dividido em **Fluxo 1** (preparar e enviar a confirmação) e **Fluxo 2** (tratar a resposta do cliente). Arquivo atual: `Claude outputs/Fluxo_Central_Lider__12-11_v26_TRAVA_REGISTRO_UNICO.json`.
- **Pasta de versões:** `Claude outputs/`. Versões antigas soltas na raiz: `Fluxo_Central_Lider__04-11__SEM_CONFIRMACAO.json` e `Fluxo_Central_Lider__05-11_REVISADO.json`.
- **Padrão de nome:** `Fluxo_Central_Lider__DD-MM_vN_NOME_CURTO.json`. Nunca sobrescrever a versão anterior.
- **Diário de bordo:** `claude/DIARIO_DE_BORDO.md` no Projeto do claude.ai, espelhado no capítulo 11 do manual.
- **Revisões:** `claude/REVISAO_Fluxo_06-11_v7.md` e `claude/REVISAO_Fluxo_09-11_v8_RESPOSTA_TARDIA.md` (Projeto do claude.ai).
- **Manual do operador:** `Manual_Operador_Automacao_Central_Lider.docx` (raiz; cópia em `Claude outputs/`).
- **Fluxograma:** `Fluxograma_v9_09-11/` (7 imagens) e board "N8N" no Miro.
- **Apresentação:** `N8N.pptx`.
- **Testes automatizados:** `Claude outputs/testes_v12/`, `testes_v13/`, `testes_v14/` … `testes_v26/` (scripts Node que executam o código dos nós; `teste_painel_v18.py` roda o painel no Chrome com Playwright).
- **Fonte das etapas:** fluxograma v9 (7 partes).
- **Fora do escopo do vault:** `BKP_Biblioteca/` (backup de biblioteca de outro sistema), `n8n.md` e `n8n.txt` (exportações antigas em texto).

Atualização do vault: a cada nova versão, seguir a skill `organizar-projeto-n8n` (modo atualização) depois da ficha no diário (`diario-de-bordo-n8n`).

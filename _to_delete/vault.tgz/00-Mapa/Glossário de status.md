---
fluxo: Central Líder
versao_fluxo: v14
atualizado: 2026-11-12
tags: [glossario, status]
---
# Glossário de status

Valores da coluna `status` da [[AGUARDANDO_ENTREGA]], na ordem em que um pedido costuma passar.

| Status | Significado | Quem define |
|---|---|---|
| `EM_PROCESSAMENTO` | Pedido ainda sendo processado pelo Fluxo 1 | [[F1-1 Coleta e validação]] |
| `OUTLET` | Retirada na loja; confirmação registrada sem contato com o cliente (v13) | [[Regra - Outlet]] |
| `PENDENTE_DESTINO` | Cidade ou rota não resolvida; precisa de ação no painel | [[F1-2 Boleto e prazo]] |
| `PENDENCIA_BOLETO` / `BLOQUEADO` | Pedido com boleto pendente; não vai para confirmação | [[Regra - Trava de boleto e boleto 50%]] |
| `PENDENTE_REVISAO` | Mensagem montada, esperando o consultor na Revisão de envio | [[F1-3 Histórico e mensagem]] |
| `AGRUPADO` | Pedido que vai junto na mensagem única de outro pedido do mesmo cliente; acompanha o status do principal (v12) | [[Regra - Mensagem única por cliente]] |
| `PENDENTE_RESPOSTA_TARDIA` | Cliente respondeu depois do encerramento ou com o servidor desligado; vai para a tela de respostas tardias e fica de um dia para o outro até ser decidido (v24) | [[Regra - Resposta tardia]] |
| `AGUARDANDO_CHAMADO_LIVRE` | Chamado do contato ocupado por outro atendente; nova tentativa a cada 30 min | [[Regra - Chamado ocupado]] |
| `AGUARDANDO` | Template enviado; cliente ainda não aceitou | [[F1-4 Liberação e envio]] |
| `DATA_ENVIADA` | Cliente aceitou o template e recebeu a mensagem de confirmação (pode receber o lembrete das 13h) | [[F2-1 Respostas do cliente]] |
| `AGUARDANDO_CONSULTOR` | IA não soube responder; dúvida no chat do consultor | [[F2-2 Dúvidas e consultor]] |
| `AGUARDANDO_DECISAO_RESPONSAVEL` | Adiamento fora da regra; oferecido contato com o responsável | [[Regra - Adiamento e armazenagem]] |
| `ESCALADO` | Encaminhado ao consultor (2 dias sem retorno, já encaminhado antes ou pedido de contato) | [[Regra - Reincidência sem retorno]] |
| `TRANSFERIDO` / `TRANSFERENCIA_MANUAL` | Chamado transferido ao responsável (ou transferência a fazer à mão) | [[F2-1 Respostas do cliente]] |
| `CONCLUIDO` | Atendimento automático encerrado; vigilância de 1 h aberta | [[Regra - Vigilância e lembretes ao consultor]] |

Status da [[SEM_CONFIRMACAO_DIARIO]]: `ESCALADO`, `RESPONDEU_DEPOIS`, `RESPOSTA_TARDIA_TRATADA` (os dois últimos não contam como dia sem retorno).

## Ligações
**➡️ Usado em:** [[Index_Central_Lider]]

---
fluxo: Central Líder
etapa: F2-1 Respostas do cliente
parte: 05_Fluxo2_Parte1_Respostas_do_cliente.png
versao_fluxo: v26
atualizado: 2026-11-12
nos: ["Registrar mensagem do cliente", "Aguardar cliente terminar (60s)", "Escolher Linha", Switch, "POST Enviar mensagem para contato ja cadastrado", "Basic LLM Chain", "Normalizar Categoria", "Adiamento válido?", "Expandir adiamento (grupo)", "Alterar Data na Intranet - Adiamento", "Enviar Confirmação Adiamento", "Transferir chamado ao responsável - Central", "Sheet – Resposta Cliente", "Observação Intranet - Contato Cliente", "Abrir vigilância (1h)"]
tags: [etapa]
---
# Etapa: F2-1 Respostas do cliente

**Responsabilidade:** Trata cada mensagem do cliente: envia a confirmação depois do aceite do template, classifica a resposta com IA e aplica aceite, adiamento ou contato com o responsável.
**Fluxograma:** `Fluxograma_v9_09-11/05_Fluxo2_Parte1_Respostas_do_cliente.png`

## Nós principais
- `Registrar mensagem do cliente`: grava a mensagem
- `Aguardar cliente terminar (60s)`: agrupa mensagens seguidas (20 s até a v25)
- `Escolher Linha`: acha o pedido; trata a janela de vigilância
- `Switch`: aceite do template x resposta x vigilância
- `POST Enviar mensagem para contato ja cadastrado`: envia a mensagem de confirmação
- `Basic LLM Chain`: IA classifica a resposta
- `Fora da regra? (1ª resposta)`: assunto que as regras não cobrem → consulta a base antes (v26)
- `Normalizar Categoria`: aplica as regras sobre a classificação
- `Adiamento válido?`: decide se altera a data
- `Expandir adiamento (grupo)`: 1 alteração por pedido do grupo (v12)
- `Alterar Data na Intranet - Adiamento`: altera a data
- `Enviar Confirmação Adiamento`: confirma o adiamento com aviso de armazenagem
- `Transferir chamado ao responsável - Central`: transfere quando o cliente aceita
- `Sheet – Resposta Cliente`: registra na planilha
- `Montar registro único` / `Gravar registro único (AGUARDANDO_ENTREGA)`: marca que o contato foi registrado (v26)
- `Observação Intranet - Contato Cliente`: registra a observação
- `Abrir vigilância (1h)`: abre a janela de 1 h

## Saídas possíveis
- Aceita → `CONCLUIDO`, planilha e intranet atualizadas, vigilância de 1 h
- Adiamento válido → data alterada na intranet + confirmação
- Adiamento fora da regra → oferece o responsável (`AGUARDANDO_DECISAO_RESPONSAVEL`)
- Assunto fora das regras → base de conhecimento; se a base não sabe → [[F2-2 Dúvidas e consultor]] sem responder e sem gravar (v26)
- Depois do registro → nada é gravado de novo; nova data ou recusa vão ao consultor (v26)
- Dúvida ou IA insegura → [[F2-2 Dúvidas e consultor]]

## Cuidados
- Confiança da IA abaixo de 0,5 = categoria `OUTRO` (vai para o consultor).
- v26: planilha e observação da intranet uma vez só por pedido ([[Regra - Registro único do contato]]). Depois de um adiamento, a IA usa a data registrada como referência.
- Em mensagem única, a resposta vale para todos os pedidos do grupo (planilha, intranet, adiamento).
- A resposta ao lembrete das 13h entra aqui normalmente (o lembrete fica no histórico como BOT).
- v18: `Agrupar mensagens do cliente` corta o histórico na última marca RECOMECO do contato ([[Regra - Recomeço do pedido]]).
- v21: `Agrupar mensagens do cliente` para a execução repetida da mesma mensagem; antes da mensagem programada, da resposta fixa e da confirmação de adiamento entram os nós "Anti-repetição" ([[Regra - Anti-repetição de mensagens]]).

## Ligações
**⬅️ Vem de:** [[Gatilho - Resposta do cliente (DigiSac)]] · [[F1-4 Liberação e envio]] · [[F2-3 Automações agendadas]]
**➡️ Vai para:** [[F2-2 Dúvidas e consultor]]
**🗄️ Dados:** [[MENSAGENS_CLIENTE]] · [[AGUARDANDO_ENTREGA]] · [[Planilha de confirmações]] · [[Intranet Líder]] · [[DigiSac]] · [[Gemini (IA)]]
**📏 Regras:** [[Regra - Classificação da resposta do cliente]] · [[Regra - Adiamento e armazenagem]] · [[Regra - Vigilância e lembretes ao consultor]] · [[Regra - Mensagem única por cliente]] · [[Regra - Anti-repetição de mensagens]] · [[Regra - Registro único do contato]]

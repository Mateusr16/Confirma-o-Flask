---
fluxo: Central Líder
etapa: F2-2 Dúvidas e consultor
parte: 06_Fluxo2_Parte2_Duvidas_e_consultor.png
versao_fluxo: v14
atualizado: 2026-11-12
nos: ["IA - Classificar mensagem (vigilância)", "Ler base de conhecimento", "IA - Buscar resposta na base", "Enviar resposta da base ao cliente", "Contar uso da base", "Montar chat com consultor", "Processar ação do consultor", "IA - Redigir resposta do consultor", "Enviar orientação do consultor ao cliente", "IA - Extrair aprendizado", "Salvar na base de conhecimento", "Transferir chamado (Consultor)", "Itens do registro (consultor)"]
tags: [etapa]
---
# Etapa: F2-2 Dúvidas e consultor

**Responsabilidade:** Responde dúvidas pela base de conhecimento; o que a base não resolve vai para o chat do consultor no painel, e a orientação do consultor volta ao cliente e alimenta a base.
**Fluxograma:** `Fluxograma_v9_09-11/06_Fluxo2_Parte2_Duvidas_e_consultor.png`

## Nós principais
- `IA - Classificar mensagem (vigilância)`: classifica mensagem depois do encerramento
- `Ler base de conhecimento`: lê perguntas e respostas
- `IA - Buscar resposta na base`: procura a resposta
- `Enviar resposta da base ao cliente`: responde automaticamente
- `Contar uso da base`: conta o uso
- `Montar chat com consultor`: abre a consulta
- `Processar ação do consultor`: lê a orientação do painel
- `IA - Redigir resposta do consultor`: redige a resposta
- `Enviar orientação do consultor ao cliente`: envia
- `IA - Extrair aprendizado`: gera pergunta/resposta
- `Salvar na base de conhecimento`: grava aprendizado novo
- `Transferir chamado (Consultor)`: transfere ao responsável
- `Itens do registro (consultor)`: 1 registro por pedido do grupo (v12)

## Saídas possíveis
- Base respondeu → resposta automática ao cliente
- Base não respondeu → `AGUARDANDO_CONSULTOR` no painel
- v26: na 1ª resposta, assunto fora das regras também passa pela base antes do consultor (nós "(1ª resposta)"). A pergunta ao consultor diz o assunto e se o pedido já estava registrado.
- v26: "Só registrar resultado" é recusado se o contato do pedido já foi registrado (registro único).
- Consultor orienta → IA redige e envia; aprendizado salvo na base
- Consultor transfere → chamado vai ao responsável

## Cuidados
- A varredura cobra o consultor por e-mail após 1 h sem resposta (máx. 4 lembretes).

## Ligações
**⬅️ Vem de:** [[F2-1 Respostas do cliente]] · [[Gatilho - Consultor (Chat)]]
**➡️ Vai para:** [[F2-3 Automações agendadas]] · [[Painel Central Líder]]
**🗄️ Dados:** [[BASE_CONHECIMENTO]] · [[AGUARDANDO_ENTREGA]] · [[Planilha de confirmações]] · [[Intranet Líder]] · [[DigiSac]] · [[Gemini (IA)]] · [[E-mails de alerta]]
**📏 Regras:** [[Regra - Vigilância e lembretes ao consultor]] · [[Regra - Classificação da resposta do cliente]] · [[Regra - Anti-repetição de mensagens]] (resposta da base)

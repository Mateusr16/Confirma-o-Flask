---
fluxo: Central Líder
etapa: F1-1 Coleta e validação
parte: 01_Fluxo1_Parte1_Coleta_e_validacao.jpg
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Separar dias anteriores", "Arquivar no HISTORICO_PEDIDOS", "Get row(s) in sheet", "Preparar Pedido", "Anotar Pedidos Iniciais", "Login Intranet", "Buscar Pedido", "Extrair Dados Pedido", "Pedido cancelado?", "Entrega Parcial?", "entrega já realizada?", "Verificar Planejado Data Absurda"]
tags: [etapa]
---
# Etapa: F1-1 Coleta e validação

**Responsabilidade:** Lê os pedidos do dia na planilha, faz a limpeza diária das tabelas, consulta cada pedido na intranet e tira da fila os cancelados e os já entregues.
**Fluxograma:** `Fluxograma_v9_09-11/01_Fluxo1_Parte1_Coleta_e_validacao.jpg`

## Nós principais
- `Separar dias anteriores`: separa linhas de dias anteriores para arquivar
- `Arquivar no HISTORICO_PEDIDOS`: guarda o histórico antes de apagar
- `Get row(s) in sheet`: lê os pedidos da planilha
- `Preparar Pedido`: normaliza os campos do pedido
- `Anotar Pedidos Iniciais`: registra os pedidos do dia
- `Login Intranet`: abre sessão na intranet
- `Buscar Pedido`: consulta o pedido (lojas.php)
- `Extrair Dados Pedido`: lê datas, cliente e itens
- `Pedido cancelado?`: desvia cancelados
- `Entrega Parcial?`: trata pedido com entrega parcial
- `entrega já realizada?`: desvia pedidos entregues
- `Verificar Planejado Data Absurda`: marca planejado com data fictícia

## Saídas possíveis
- Cancelado → marca na tabela e na planilha e sai do fluxo ([[Regra - Pedido cancelado ou entregue]])
- Já entregue → marca entregue, avisa a expedição por e-mail e sai
- Demais → [[F1-2 Boleto e prazo]]

## Cuidados
- A limpeza diária só apaga linhas de dias anteriores; linhas sem data são mantidas.
- Pendência herdada da v4: a limpeza também arquiva pedidos ainda em andamento (item 11 da revisão).

## Ligações
**⬅️ Vem de:** [[Gatilho - Disparo pelo painel]] · [[Gatilho - Execução manual]]
**➡️ Vai para:** [[F1-2 Boleto e prazo]]
**🗄️ Dados:** [[Planilha de confirmações]] · [[AGUARDANDO_ENTREGA]] · [[HISTORICO_PEDIDOS]] · [[FLUXO_STATUS]] · [[Intranet Líder]] · [[E-mails de alerta]]
**📏 Regras:** [[Regra - Limpeza diária]] · [[Regra - Pedido cancelado ou entregue]] · [[Regra - Planejados e data fictícia]]

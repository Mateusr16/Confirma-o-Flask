---
fluxo: Central Líder
etapa: F1-4 Liberação e envio
parte: 04_Fluxo1_Parte4_Liberacao_e_envio.png
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Decidir Revisão", "Veio da resposta tardia?", "Mapear Responsável", "Timer envio Template", "Avaliar chamado (envio)", "Chamado livre? (envio)", "POST Enviar template com botao", "POST Transferencia de chamado", AGUARDANDO_RESPOSTA, "Marcar aguardando chamado livre"]
tags: [etapa]
---
# Etapa: F1-4 Liberação e envio

**Responsabilidade:** Recebe a decisão do consultor no painel e envia o template do WhatsApp, mas só quando o chamado do contato está livre.
**Fluxograma:** `Fluxograma_v9_09-11/04_Fluxo1_Parte4_Liberacao_e_envio.png`

## Nós principais
- `Decidir Revisão`: aplica envio, edição da mensagem ou cancelamento
- `Veio da resposta tardia?`: trata a decisão da tela de respostas tardias
- `Mapear Responsável`: acha o usuário DigiSac do responsável
- `Timer envio Template`: intervalo de ~5 s entre envios
- `Avaliar chamado (envio)`: confere se há chamado aberto de outro atendente
- `Chamado livre? (envio)`: envia ou espera
- `POST Enviar template com botao`: envia o template com botão
- `POST Transferencia de chamado`: transfere o chamado
- `AGUARDANDO_RESPOSTA`: status `AGUARDANDO`
- `Marcar aguardando chamado livre`: status `AGUARDANDO_CHAMADO_LIVRE`

## Saídas possíveis
- Enviado → `AGUARDANDO` (o cliente aceita o template e a resposta cai em [[F2-1 Respostas do cliente]])
- Chamado ocupado → `AGUARDANDO_CHAMADO_LIVRE`, nova tentativa em [[F2-3 Automações agendadas]]
- Cancelado → nada é enviado

## Cuidados
- Qualquer dúvida na consulta do chamado (erro na API, resposta estranha) = não envia.
- A mensagem de confirmação (editada ou padrão) só vai depois do aceite do template.

## Ligações
**⬅️ Vem de:** [[Gatilho - Decisão de Envio]] · [[F1-3 Histórico e mensagem]]
**➡️ Vai para:** [[F2-1 Respostas do cliente]] · [[F2-3 Automações agendadas]]
**🗄️ Dados:** [[AGUARDANDO_ENTREGA]] · [[SEM_CONFIRMACAO_DIARIO]] · [[DigiSac]]
**📏 Regras:** [[Regra - Chamado ocupado]] · [[Regra - Edição da mensagem na Revisão]] · [[Regra - Resposta tardia]]

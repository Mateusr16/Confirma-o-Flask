---
fluxo: Central Líder
etapa: F2-3 Automações agendadas
parte: 07_Fluxo2_Parte3_Automacoes_agendadas.png
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Filtrar sem retorno elegível", "Registrar sem confirmação do dia", "Filtrar reenvio elegível", "Selecionar ações da varredura", "Preparar retomada do envio", "Enviar template (retomada)", "Filtrar lembrete elegível", "Enviar lembrete ao cliente"]
tags: [etapa]
---
# Etapa: F2-3 Automações agendadas

**Responsabilidade:** Rotinas que rodam sozinhas: lembrete de confirmação, reenvio do template, encerramento de quem não respondeu, varredura de vigilância e nova tentativa nos chamados ocupados.
**Fluxograma:** `Fluxograma_v9_09-11/07_Fluxo2_Parte3_Automacoes_agendadas.png`

## Nós principais
- `Filtrar sem retorno elegível`: encerramento do dia
- `Registrar sem confirmação do dia`: anota o dia sem retorno
- `Filtrar reenvio elegível`: reenvio do template
- `Selecionar ações da varredura`: vigilância e lembretes
- `Preparar retomada do envio`: fila de chamados ocupados
- `Enviar template (retomada)`: envio quando o chamado libera
- `Filtrar lembrete elegível`: lembrete das 13h
- `Enviar lembrete ao cliente`: envia o lembrete

## Saídas possíveis
- Lembrete → 1 mensagem curta a quem está em `DATA_ENVIADA` sem responder; status continua `DATA_ENVIADA`
- Sem retorno → chamado fechado, planilha e SEM_CONFIRMACAO_DIARIO atualizadas
- Reenvio → template reenviado uma vez
- Vigilância vencida → chamado fechado (CONCLUIDO) ou só limpeza
- Chamado liberado → template enviado e status `AGUARDANDO`

## Cuidados
- Ordem do dia: 13:00 lembrete · 13:20 reenvio · 16:20 (sex 15:20) encerramento.
- Os comentários no código ainda citam horários antigos (12:30, 16:30, 15:30); valem os horários do agendamento.

## Ligações
**⬅️ Vem de:** [[Gatilho - Lembrete de confirmação (13h)]] · [[Gatilho - Encerramento de pendências]] · [[Gatilho - Reenvio do template]] · [[Gatilho - Varredura de vigilância]] · [[Gatilho - Chamados ocupados]]
**➡️ Vai para:** [[F2-1 Respostas do cliente]] · [[F1-3 Histórico e mensagem]]
**🗄️ Dados:** [[AGUARDANDO_ENTREGA]] · [[SEM_CONFIRMACAO_DIARIO]] · [[MENSAGENS_CLIENTE]] · [[Planilha de confirmações]] · [[DigiSac]] · [[E-mails de alerta]]
**📏 Regras:** [[Regra - Lembrete de confirmação (13h)]] · [[Regra - Encerramento sem retorno]] · [[Regra - Reenvio do template]] · [[Regra - Vigilância e lembretes ao consultor]] · [[Regra - Chamado ocupado]]

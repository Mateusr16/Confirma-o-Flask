---
fluxo: Central Líder
etapa: F1-3 Histórico e mensagem
parte: 03_Fluxo1_Parte3_Historico_e_mensagem.png
versao_fluxo: v20
atualizado: 2026-11-11
nos: ["Verificar reincidência sem retorno", "Reincidente sem retorno?", "Marcar já encaminhado (AGUARDANDO_ENTREGA)", "Enviar e-mail ao consultor (reincidência)", "Verificar resposta tardia", "Pedido com pendência de boleto?", "Busca Digisac", "Criar Contato", "Separ produtos", "Montar Mensagem Soltos", "Montar Mensagem Planejados", "Junção envio dos template", "Agrupar pedidos do mesmo cliente", "Registrar Revisão"]
tags: [etapa]
---
# Etapa: F1-3 Histórico e mensagem

**Responsabilidade:** Olha o histórico do cliente (dias sem retorno, respostas tardias), acha o contato no DigiSac e monta a mensagem de confirmação de cada pedido.
**Fluxograma:** `Fluxograma_v9_09-11/03_Fluxo1_Parte3_Historico_e_mensagem.png`

## Nós principais
- `Verificar reincidência sem retorno`: conta dias sem retorno
- `Reincidente sem retorno?`: escalar, já escalado ou seguir
- `Marcar já encaminhado (AGUARDANDO_ENTREGA)`: grava `ESCALADO` para quem já tinha ido ao consultor (v11)
- `Enviar e-mail ao consultor (reincidência)`: avisa o consultor
- `Verificar resposta tardia`: procura mensagem depois do encerramento
- `Pedido com pendência de boleto?`: segura pedidos travados
- `Busca Digisac`: procura o contato pelo celular
- `Criar Contato`: cria o contato se não existir
- `Separ produtos`: separa Móveis soltos e Planejados
- `Montar Mensagem Soltos`: lista os produtos e a data
- `Montar Mensagem Planejados`: 1ª ou 2ª confirmação
- `Junção envio dos template`: junta soltos e planejados
- `Agrupar pedidos do mesmo cliente`: uma mensagem para vários pedidos do mesmo contato (v12)
- `Registrar Revisão`: grava a mensagem para revisão no painel

## Saídas possíveis
- Reincidente (2 dias sem retorno) → e-mail ao consultor, status `ESCALADO`
- Já encaminhado antes → status `ESCALADO` com o motivo no `resumoIA` (antes ficava preso em `EM_PROCESSAMENTO`)
- Mesmo cliente com 2+ pedidos → 1 mensagem; os outros pedidos ficam `AGRUPADO` ([[Regra - Mensagem única por cliente]])
- Resposta tardia → `PENDENTE_RESPOSTA_TARDIA`, tela de respostas tardias
- Demais → `PENDENTE_REVISAO`, Revisão de envio no [[Painel Central Líder]] → [[F1-4 Liberação e envio]]

## Cuidados
- v20: `Preparar Tentativas Digisac` lê o documento de 15 dígitos da intranet (CPF = 9 dígitos + 0000 + 2; CNPJ = 0 + 14) e confere os dígitos verificadores; é ele que vai na frente do nome no `Criar Contato`.
- Celular inválido ou contato não encontrado: o pedido fica marcado com erro de busca e não recebe mensagem.
- Planejados sem a lista de projetos carregada são bloqueados para revisão (não enviam nada errado).

## Ligações
**⬅️ Vem de:** [[F1-2 Boleto e prazo]]
**➡️ Vai para:** [[F1-4 Liberação e envio]] · [[Painel Central Líder]]
**🗄️ Dados:** [[SEM_CONFIRMACAO_DIARIO]] · [[MENSAGENS_CLIENTE]] · [[AGUARDANDO_ENTREGA]] · [[DigiSac]] · [[Intranet Líder]] · [[E-mails de alerta]]
**📏 Regras:** [[Regra - Reincidência sem retorno]] · [[Regra - Resposta tardia]] · [[Regra - Planejados e data fictícia]] · [[Regra - Mensagem única por cliente]]

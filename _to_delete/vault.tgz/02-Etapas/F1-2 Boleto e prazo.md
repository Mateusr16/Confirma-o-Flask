---
fluxo: Central Líder
etapa: F1-2 Boleto e prazo
parte: 02_Fluxo1_Parte2_Boleto_e_prazo.png
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Pular boleto?", "Conferir Boletos", "Tratar Conferência Boleto", "Analisar 50% do Pedido", "Calcular Nova Data Boleto 50%", "Alterar Data - Boleto 50%", "Bloquear pedido (pendência de boleto)", "Classificar Tipo de Móvel", "Geocodificar Cidade", "Calcular Rota OSRM", "Tratar Distância", "Consultar estoque (outlet)", "Verificar outlet", "É outlet?", "Marcar outlet (AGUARDANDO_ENTREGA)", "Sheet – Outlet", "Observação Intranet (outlet)", "Registrar Pendência Central", "Calcular Data de Entrega"]
tags: [etapa]
---
# Etapa: F1-2 Boleto e prazo

**Responsabilidade:** Confere o boleto do pedido, trata a regra de 50%, separa os pedidos de outlet, classifica o tipo de móvel e calcula a data de entrega com a distância até o cliente.
**Fluxograma:** `Fluxograma_v9_09-11/02_Fluxo1_Parte2_Boleto_e_prazo.png`

## Nós principais
- `Pular boleto?`: planejado com data fictícia pula a conferência
- `Conferir Boletos`: consulta pagamentos na intranet
- `Tratar Conferência Boleto`: classifica OK, ANALISAR, NAO_ENCONTRADO, ERRO_CONSULTA
- `Analisar 50% do Pedido`: acha a parcela que completa 50%
- `Calcular Nova Data Boleto 50%`: calcula a nova data
- `Alterar Data - Boleto 50%`: altera a data na intranet
- `Bloquear pedido (pendência de boleto)`: trava o pedido
- `Classificar Tipo de Móvel`: Planejados ou Móveis soltos
- `Geocodificar Cidade`: acha coordenadas
- `Calcular Rota OSRM`: distância por estrada
- `Tratar Distância`: aplica a regra dos 100 km
- `Consultar estoque (outlet)`: lê quantidade x estoque dos itens
- `Verificar outlet`: aplica a regra do outlet
- `É outlet?`: outlet sai do fluxo aqui
- `Marcar outlet (AGUARDANDO_ENTREGA)`: status `OUTLET`
- `Sheet – Outlet`: planilha SIM / CONFIRMADO
- `Observação Intranet (outlet)`: aviso na intranet
- `Registrar Pendência Central`: pedido sem destino vai para o painel
- `Calcular Data de Entrega`: soma dias úteis

## Saídas possíveis
- Boleto pendente → bloqueado, nunca vai para confirmação ([[Regra - Trava de boleto e boleto 50%]])
- Outlet → `OUTLET`, confirmado sem contato com o cliente ([[Regra - Outlet]])
- Sem origem/destino → `PENDENTE_DESTINO`, resolvido no painel via [[Gatilho - Resolver Pendência]]
- Demais → [[F1-3 Histórico e mensagem]]

## Cuidados
- Se o OSRM falhar, a distância é estimada em linha reta × 1,35.
- Pendência herdada da v5: planejados com data fictícia pulam a conferência de boleto (item 9 da revisão).

## Ligações
**⬅️ Vem de:** [[F1-1 Coleta e validação]] · [[Gatilho - Resolver Pendência]]
**➡️ Vai para:** [[F1-3 Histórico e mensagem]]
**🗄️ Dados:** [[AGUARDANDO_ENTREGA]] · [[Planilha de confirmações]] · [[Intranet Líder]] · [[Rotas (Nominatim e OSRM)]] · [[E-mails de alerta]]
**📏 Regras:** [[Regra - Trava de boleto e boleto 50%]] · [[Regra - Outlet]] · [[Regra - Planejados e data fictícia]] · [[Regra - Tipo de móvel por responsável]] · [[Regra - Prazo de entrega e distância]]

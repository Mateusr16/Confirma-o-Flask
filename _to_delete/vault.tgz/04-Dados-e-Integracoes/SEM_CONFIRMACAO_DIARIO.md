---
recurso: SEM_CONFIRMACAO_DIARIO
tipo: tabela
versao_fluxo: v14
atualizado: 2026-11-12
nos: ["Registrar sem confirmação do dia", "Ler SEM_CONFIRMACAO_DIARIO", "Marcar escalado (sem confirmação)", "Marcar respondeu depois (SEM_CONFIRMACAO)", "Marcar resposta tardia tratada"]
tags: [dados, tabela]
---
# SEM_CONFIRMACAO_DIARIO

**Para que serve:** registro diário de pedidos encerrados sem retorno; base da reincidência e da resposta tardia.
v24: `dataRef` pode ser o dia do pedido (encerramento feito pela varredura da manhã), não só o dia do encerramento.
**Campos usados:** `pedidoLider`, `cliente`, `responsavel`, `contactId`, `dataRef`, `status`, `registradoEm`.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Registrar sem confirmação do dia` | upsert | [[F2-3 Automações agendadas]] |
| `Ler SEM_CONFIRMACAO_DIARIO` | get | [[F1-3 Histórico e mensagem]] |
| `Marcar escalado (sem confirmação)` | update | [[F1-3 Histórico e mensagem]] |
| `Marcar respondeu depois (SEM_CONFIRMACAO)` | update | [[F1-3 Histórico e mensagem]] |
| `Marcar resposta tardia tratada` | update | [[F1-4 Liberação e envio]] |
| `Ler SEM_CONFIRMACAO (varredura tardia)` | get | [[Gatilho - Varredura de respostas tardias]] |
| `Marcar respondeu depois (varredura tardia)` | update | [[Gatilho - Varredura de respostas tardias]] |
| `Marcar resposta tardia tratada (registro)` | update | [[Gatilho - Consultor (Chat)]] |

## Ligações
**⬅️ Usado por:** [[F1-3 Histórico e mensagem]] · [[F1-4 Liberação e envio]] · [[F2-3 Automações agendadas]] · [[Regra - Reincidência sem retorno]] · [[Regra - Resposta tardia]]

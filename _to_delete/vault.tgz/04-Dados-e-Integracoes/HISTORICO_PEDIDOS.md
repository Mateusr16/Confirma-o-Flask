---
recurso: HISTORICO_PEDIDOS
tipo: tabela
versao_fluxo: v14
atualizado: 2026-11-12
nos: ["Arquivar no HISTORICO_PEDIDOS"]
tags: [dados, tabela]
---
# HISTORICO_PEDIDOS

**Para que serve:** histórico dos pedidos de dias anteriores, arquivados pela limpeza diária.
**Campos usados:** `idOriginal`, `dataReferencia`, `pedidoLider`, `cliente`, `responsavel`, `status`, `criadoEm`, `atualizadoEm`, `arquivadoEm`, `dados`.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Arquivar no HISTORICO_PEDIDOS` | upsert | [[F1-1 Coleta e validação]] |
| `Ler HISTORICO_PEDIDOS (varredura tardia)` | get (recria o cartão se a linha já foi arquivada) | [[Gatilho - Varredura de respostas tardias]] |

## Ligações
**⬅️ Usado por:** [[F1-1 Coleta e validação]] · [[Regra - Limpeza diária]] · [[Gatilho - Varredura de respostas tardias]]

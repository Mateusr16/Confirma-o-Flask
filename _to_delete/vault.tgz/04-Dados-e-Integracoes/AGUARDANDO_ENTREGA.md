---
recurso: AGUARDANDO_ENTREGA
tipo: tabela
versao_fluxo: v18
atualizado: 2026-11-12
nos: ["Anotar Pedidos Iniciais", "Registrar Revisão", AGUARDANDO_RESPOSTA, "Buscar Linhas", "Update final", "Abrir vigilância (1h)", "Marcar consulta respondida", "Ler linhas para varredura", Pendente_destino, "Marcar já encaminhado (AGUARDANDO_ENTREGA)", "Marcar outlet (AGUARDANDO_ENTREGA)", "Reconferir pedido (lembrete)", "Marcar lembrete enviado", "Gravar recomeço (AGUARDANDO_ENTREGA)", "Atualizar contato (pedidos do grupo)"]
tags: [dados, tabela]
---
# AGUARDANDO_ENTREGA

**Para que serve:** tabela central do fluxo: uma linha por pedido do dia, com status, mensagem, contato DigiSac e chat do consultor.
**Campos usados:** `pedidoLider`, `cliente`, `responsavel`, `status`, `mensagem`, `tipoMensagem`, `template`, `anexoUrl`, `contactId`, `phone`, `serviceId`, `enviadoEm`, `respondidoEm`, `resposta`, `respostaData`, `categoria`, `resumoIA`, `chatConsultor`, `vigiaAte`, `dadosPedido`.
Valores de `status`: ver [[Glossário de status]]. Dentro do `dadosPedido` ficam `pedidosGrupo`/`agrupadoEm` (mensagem única), `motivoOutlet` e `lembreteConfirmacaoEm`/`lembreteConfirmacaoTexto` e, desde a v18, `recomecos` (histórico de cada recomeço), `contatoAlternativo` e `mensagemAntesRecomeco`.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Anotar Pedidos Iniciais` | upsert | [[F1-1 Coleta e validação]] |
| `Registrar Revisão` | upsert | [[F1-3 Histórico e mensagem]] |
| `AGUARDANDO_RESPOSTA` | update | [[F1-4 Liberação e envio]] |
| `Buscar Linhas` | get | [[F2-1 Respostas do cliente]] |
| `Update final` | update | [[F2-1 Respostas do cliente]] |
| `Abrir vigilância (1h)` | update | [[F2-1 Respostas do cliente]] |
| `Marcar consulta respondida` | update | [[F2-2 Dúvidas e consultor]] |
| `Ler linhas para varredura` | get | [[F2-3 Automações agendadas]] |
| `Pendente_destino` | get | [[Painel Central Líder]] |
| `Marcar já encaminhado (AGUARDANDO_ENTREGA)` | update | [[F1-3 Histórico e mensagem]] |
| `Marcar outlet (AGUARDANDO_ENTREGA)` | update | [[F1-2 Boleto e prazo]] |
| `Reconferir pedido (lembrete)` | get | [[F2-3 Automações agendadas]] |
| `Marcar lembrete enviado` | update | [[F2-3 Automações agendadas]] |
| `Buscar pedido (recomeço)` / `Outros pedidos do contato (recomeço)` / `Reler pedido (recomeço)` | get | [[Gatilho - Recomeçar pedido]] |
| `Gravar recomeço (AGUARDANDO_ENTREGA)` / `Atualizar contato (pedidos do grupo)` | update | [[Gatilho - Recomeçar pedido]] |

## Ligações
**⬅️ Usado por:** [[F1-1 Coleta e validação]] · [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]] · [[F1-4 Liberação e envio]] · [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[F2-3 Automações agendadas]] · [[Painel Central Líder]] · [[Gatilho - Recomeçar pedido]]

v24: `Gravar cartão tardio (varredura tardia)` faz upsert por `pedidoLider` com `PENDENTE_RESPOSTA_TARDIA`; `Ler AGUARDANDO_ENTREGA (varredura tardia)` lê a tabela. Ver [[Gatilho - Varredura de respostas tardias]].

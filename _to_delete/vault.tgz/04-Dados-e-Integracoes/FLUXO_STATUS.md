---
recurso: FLUXO_STATUS
tipo: tabela
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Salvar evento inicial", "Salvar evento de status", "Apagar eventos antigos", "Ler eventos do disparo"]
tags: [dados, tabela]
---
# FLUXO_STATUS

**Para que serve:** eventos de progresso de cada disparo, lidos pela barra de progresso do painel.
**Campos usados:** `disparoId`, `tipo`, `no`, `msg`, `pct`, `ts`.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Salvar evento inicial` | insert | [[F1-1 Coleta e validação]] |
| `Salvar evento de status` | insert | [[F1-1 Coleta e validação]] |
| `Apagar eventos antigos` | deleteRows | [[F1-1 Coleta e validação]] |
| `Ler eventos do disparo` | get | [[Painel Central Líder]] |

## Ligações
**⬅️ Usado por:** [[F1-1 Coleta e validação]] · [[Gatilho - Status do disparo]] · [[Gatilho - Erro no fluxo]]

---
recurso: E-mails de alerta
tipo: email
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Send an Email1", "E-mail alerta 50% (falha)", "Enviar e-mail ao consultor (reincidência)", "Avisar falha no mapeamento do responsável", "E-mail lembrete ao responsável", "E-mail alerta de erro"]
tags: [dados, email]
---
# E-mails de alerta

**Para que serve:** alertas por e-mail ao consultor, à expedição e aos responsáveis (11 nós).


## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Send an Email1` | expedição: pedido já entregue | [[F1-1 Coleta e validação]] |
| `E-mail alerta 50% (falha)` | falha no boleto 50% | [[F1-2 Boleto e prazo]] |
| `Enviar e-mail ao consultor (reincidência)` | reincidência | [[F1-3 Histórico e mensagem]] |
| `Avisar falha no mapeamento do responsável` | falha de transferência | [[F2-1 Respostas do cliente]] |
| `E-mail lembrete ao responsável` | lembrete do consultor | [[F2-3 Automações agendadas]] |
| `E-mail alerta de erro` | erro no fluxo | [[F2-3 Automações agendadas]] |

## Ligações
**⬅️ Usado por:** [[F1-1 Coleta e validação]] · [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]] · [[F2-1 Respostas do cliente]] · [[F2-3 Automações agendadas]] · [[Gatilho - Erro no fluxo]]

---
recurso: BASE_CONHECIMENTO
tipo: tabela
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Ler base de conhecimento", "Contar uso da base", "Ler base (aprendizado)", "Atualizar base de conhecimento", "Salvar na base de conhecimento"]
tags: [dados, tabela]
---
# BASE_CONHECIMENTO

**Para que serve:** perguntas e respostas usadas pela IA para responder dúvidas sem o consultor; cresce com o aprendizado do chat do consultor.
**Campos usados:** `pergunta`, `resposta`, `usos`, `ultimoUso`, `criadoEm`, `atualizadoEm`.

> Pendência da v10: cadastrar a regra de armazenagem na base.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Ler base de conhecimento` | get | [[F2-2 Dúvidas e consultor]] |
| `Contar uso da base` | update | [[F2-2 Dúvidas e consultor]] |
| `Ler base (aprendizado)` | get | [[F2-2 Dúvidas e consultor]] |
| `Atualizar base de conhecimento` | update | [[F2-2 Dúvidas e consultor]] |
| `Salvar na base de conhecimento` | insert | [[F2-2 Dúvidas e consultor]] |

## Ligações
**⬅️ Usado por:** [[F2-2 Dúvidas e consultor]]

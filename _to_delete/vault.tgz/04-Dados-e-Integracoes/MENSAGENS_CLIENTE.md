---
recurso: MENSAGENS_CLIENTE
tipo: tabela
versao_fluxo: v20
atualizado: 2026-11-12
nos: ["Registrar mensagem do cliente", "Ler conversa do cliente", "Registrar resposta da Líder", "Ler MENSAGENS_CLIENTE (resposta tardia)", "Ler MENSAGENS_CLIENTE (lembrete)", "Registrar lembrete na conversa", "Marcar recomeço na conversa", "Registrar aviso na conversa"]
tags: [dados, tabela]
---
# MENSAGENS_CLIENTE

**Para que serve:** histórico das mensagens trocadas com o cliente (cliente e Líder).
**Campos usados:** `contactId`, `messageId`, `papel`, `texto`, `recebidoEm`, `ts`.

Grava as mensagens dos clientes desde 09/11, 08:43. Desde a v24, a varredura da manhã também grava as que o webhook não recebeu (servidor desligado), com o `ts` original da mensagem. `papel`: CLIENTE, Líder ou BOT (lembrete das 13h) ou RECOMECO (v18: marca de recomeço; `Agrupar mensagens do cliente` ignora tudo antes dela). A coluna `ts` existe (Number); a pendência registrada em 09/11 estava errada e foi corrigida no diário em 10/11.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Registrar mensagem do cliente` | insert | [[F2-1 Respostas do cliente]] |
| `Ler conversa do cliente` | get | [[F2-1 Respostas do cliente]] |
| `Registrar resposta da Líder` | insert | [[F2-1 Respostas do cliente]] |
| `Ler MENSAGENS_CLIENTE (resposta tardia)` | get | [[F1-3 Histórico e mensagem]] |
| `Ler MENSAGENS_CLIENTE (lembrete)` | get | [[F2-3 Automações agendadas]] |
| `Registrar lembrete na conversa` | insert | [[F2-3 Automações agendadas]] |
| `Marcar recomeço na conversa` | insert | [[Gatilho - Recomeçar pedido]] |
| `Registrar aviso na conversa` | insert (BOT, contato anterior) | [[Gatilho - Recomeçar pedido]] |
| `Ler MENSAGENS_CLIENTE (varredura tardia)` | get | [[Gatilho - Varredura de respostas tardias]] |
| `Gravar mensagem recuperada (varredura tardia)` | insert (CLIENTE, horário original) | [[Gatilho - Varredura de respostas tardias]] |

## Ligações
**⬅️ Usado por:** [[F1-3 Histórico e mensagem]] · [[F2-1 Respostas do cliente]] · [[F2-3 Automações agendadas]] · [[Regra - Resposta tardia]] · [[Regra - Adiamento e armazenagem]] · [[Regra - Lembrete de confirmação (13h)]] · [[Regra - Recomeço do pedido]] · [[Regra - Anti-repetição de mensagens]]

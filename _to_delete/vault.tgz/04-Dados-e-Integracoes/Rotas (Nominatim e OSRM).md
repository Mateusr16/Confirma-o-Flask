---
recurso: Rotas (Nominatim e OSRM)
tipo: api
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Geocodificar Cidade", "Calcular Rota OSRM", "Tratar Distância"]
tags: [dados, api]
---
# Rotas (Nominatim e OSRM)

**Para que serve:** geocodificação da cidade (Nominatim/OpenStreetMap) e distância por estrada (OSRM) para a regra dos 100 km.


## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Geocodificar Cidade` | GET | [[F1-2 Boleto e prazo]] |
| `Calcular Rota OSRM` | GET | [[F1-2 Boleto e prazo]] |
| `Tratar Distância` | regra | [[F1-2 Boleto e prazo]] |

## Ligações
**⬅️ Usado por:** [[F1-2 Boleto e prazo]] · [[Regra - Prazo de entrega e distância]]

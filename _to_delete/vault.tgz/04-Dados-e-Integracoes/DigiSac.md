---
recurso: DigiSac
tipo: mensageria
versao_fluxo: v20
atualizado: 2026-11-12
nos: ["Busca Digisac", "Criar Contato", "POST Enviar template com botao", "Consultar chamado aberto (envio)", "POST Transferencia de chamado", "POST Enviar mensagem para contato ja cadastrado", "Enviar vídeo Digisac", "Fechar chamado Digisac", "Enviar lembrete ao cliente", "Consultar chamado aberto (lembrete)", "Busca Digisac (recomeço)", "Criar Contato (recomeço)", "Enviar aviso ao contato anterior"]
tags: [dados, mensageria]
---
# DigiSac

**Para que serve:** WhatsApp da Líder via DigiSac: contatos, templates com botão, mensagens, chamados e transferências.


As mensagens do cliente chegam pelo webhook [[Gatilho - Resposta do cliente (DigiSac)]]. Desde a v24, o que chegou com o servidor desligado é lido de volta pela [[Gatilho - Varredura de respostas tardias]].
**Nome dos contatos criados:** "CPF/CNPJ - CLIENTE" (`Criar Contato`) e "CPF/CNPJ - CLIENTE-(nome)" (`Criar Contato (recomeço)`). Desde a v20, o documento de 15 dígitos da intranet é lido certo: CNPJ = 0 + 14 dígitos; CPF = 9 dígitos + 0000 + 2 dígitos.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Busca Digisac` | contatos | [[F1-3 Histórico e mensagem]] |
| `Criar Contato` | contatos | [[F1-3 Histórico e mensagem]] |
| `POST Enviar template com botao` | templates | [[F1-4 Liberação e envio]] |
| `Consultar chamado aberto (envio)` | API tickets | [[F1-4 Liberação e envio]] |
| `POST Transferencia de chamado` | chamados | [[F1-4 Liberação e envio]] |
| `POST Enviar mensagem para contato ja cadastrado` | mensagens | [[F2-1 Respostas do cliente]] |
| `Enviar vídeo Digisac` | API messages | [[F2-1 Respostas do cliente]] |
| `Fechar chamado Digisac` | chamados | [[F2-3 Automações agendadas]] |
| `Enviar lembrete ao cliente` | mensagens | [[F2-3 Automações agendadas]] |
| `Consultar chamado aberto (lembrete)` | API tickets | [[F2-3 Automações agendadas]] |
| `Busca Digisac (recomeço)` | contatos | [[Gatilho - Recomeçar pedido]] |
| `Criar Contato (recomeço)` | contatos | [[Gatilho - Recomeçar pedido]] |
| `Enviar aviso ao contato anterior` | mensagens | [[Gatilho - Recomeçar pedido]] |
| `Buscar mensagens no DigiSac (varredura tardia)` | API messages (GET, por contato) | [[Gatilho - Varredura de respostas tardias]] |

## Ligações
**⬅️ Usado por:** [[F1-3 Histórico e mensagem]] · [[F1-4 Liberação e envio]] · [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[F2-3 Automações agendadas]] · [[Gatilho - Resposta do cliente (DigiSac)]] · [[Gatilho - Recomeçar pedido]]

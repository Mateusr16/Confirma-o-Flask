---
recurso: Planilha de confirmações
tipo: planilha
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Get row(s) in sheet", "Sheet – Pedido Cancelado", "Sheet – Já Faturado", "Sheet – Boleto 50%", "Sheet – Resposta Cliente", "Gravar resultado na planilha (consultor)", "Registrar sem retorno no Excel", "Sheet – Outlet"]
tags: [dados, planilha]
---
# Planilha de confirmações

**Para que serve:** planilha Google Sheets (aba Página1) com os pedidos a confirmar e o resultado de cada um.
**Campos usados:** `Pedido`, `CONFIRMADO`, `MOTIVO`, `DATA ENVIO CONF.`

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Get row(s) in sheet` | leitura | [[F1-1 Coleta e validação]] |
| `Sheet – Pedido Cancelado` | update | [[F1-1 Coleta e validação]] |
| `Sheet – Já Faturado` | update | [[F1-1 Coleta e validação]] |
| `Sheet – Boleto 50%` | update | [[F1-2 Boleto e prazo]] |
| `Sheet – Resposta Cliente` | update | [[F2-1 Respostas do cliente]] |
| `Gravar resultado na planilha (consultor)` | update | [[F2-2 Dúvidas e consultor]] |
| `Registrar sem retorno no Excel` | update | [[F2-3 Automações agendadas]] |
| `Sheet – Outlet` | update | [[F1-2 Boleto e prazo]] |

## Ligações
**⬅️ Usado por:** [[F1-1 Coleta e validação]] · [[F1-2 Boleto e prazo]] · [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[F2-3 Automações agendadas]]

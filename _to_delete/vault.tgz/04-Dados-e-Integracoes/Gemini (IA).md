---
recurso: Gemini (IA)
tipo: ia
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Basic LLM Chain", "IA - Classificar mensagem (vigilância)", "IA - Buscar resposta na base", "IA - Redigir resposta do consultor", "IA - Extrair aprendizado"]
tags: [dados, ia]
---
# Gemini (IA)

**Para que serve:** modelos Gemini para classificar respostas, buscar na base, redigir a resposta do consultor e extrair aprendizado.


## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Basic LLM Chain` | classificar resposta | [[F2-1 Respostas do cliente]] |
| `IA - Classificar mensagem (vigilância)` | classificar na vigilância | [[F2-2 Dúvidas e consultor]] |
| `IA - Buscar resposta na base` | buscar na base | [[F2-2 Dúvidas e consultor]] |
| `IA - Redigir resposta do consultor` | redigir | [[F2-2 Dúvidas e consultor]] |
| `IA - Extrair aprendizado` | aprendizado | [[F2-2 Dúvidas e consultor]] |

## Ligações
**⬅️ Usado por:** [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[Regra - Classificação da resposta do cliente]]

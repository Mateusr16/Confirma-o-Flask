---
recurso: Intranet Líder
tipo: api
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Login Intranet", "Buscar Pedido", "Conferir Boletos", "Alterar Data - Boleto 50%", "Consultar Projetos Postados", "Alterar Data na Intranet - Adiamento", "Observação Intranet - Contato Cliente", "Alterar Data (consultor)", "Consultar estoque (outlet)", "Observação Intranet (outlet)"]
tags: [dados, api]
---
# Intranet Líder

**Para que serve:** intranet da Líder (rede interna), acessada por login e páginas PHP: pedidos (lojas.php), saldo/itens (situacao_pedidos.php), pagamentos, alteração de data (altera_data_entrega.php), observação (aviso_entrega.php), e-mails (inf/emails.php) e projetos postados (listar_arq_pojetos.php).


O fluxo lê o HTML das páginas (não há API). Mudança de layout na intranet quebra os nós de extração.

## Quem lê / quem grava
| Nó | Operação | Etapa |
|---|---|---|
| `Login Intranet` | login | [[F1-1 Coleta e validação]] |
| `Buscar Pedido` | GET | [[F1-1 Coleta e validação]] |
| `Conferir Boletos` | POST | [[F1-2 Boleto e prazo]] |
| `Alterar Data - Boleto 50%` | GET | [[F1-2 Boleto e prazo]] |
| `Consultar Projetos Postados` | GET | [[F1-3 Histórico e mensagem]] |
| `Alterar Data na Intranet - Adiamento` | GET | [[F2-1 Respostas do cliente]] |
| `Observação Intranet - Contato Cliente` | GET | [[F2-1 Respostas do cliente]] |
| `Alterar Data (consultor)` | GET | [[F2-2 Dúvidas e consultor]] |
| `Consultar estoque (outlet)` | GET | [[F1-2 Boleto e prazo]] |
| `Observação Intranet (outlet)` | GET | [[F1-2 Boleto e prazo]] |

## Ligações
**⬅️ Usado por:** [[F1-1 Coleta e validação]] · [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]] · [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[Páginas salvas da intranet]]

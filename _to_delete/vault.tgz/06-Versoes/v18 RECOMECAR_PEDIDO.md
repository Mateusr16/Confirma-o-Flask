---
fluxo: Central Líder
versao: v18
data: 11/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__11-11_v18_RECOMECAR_PEDIDO.json
base: v17
atualizado: 2026-11-11
tags: [versao]
---
# v18 RECOMECAR_PEDIDO

**Data:** 11/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__11-11_v18_RECOMECAR_PEDIDO.json` · **Base:** v17

Botão 🔄 Recomeçar / 📱 Trocar número no painel: recomeça o atendimento com o mesmo número ou com outro (procura e, se preciso, cria o contato no DigiSac) e devolve o pedido à Revisão com a conversa zerada. 26 nós novos, 2 alterados (415 nós). Testes simulados: 53/53 e painel 16/16.

**Registro oficial:** ficha "11/11/2026 · v18 RECOMECAR_PEDIDO" no `DIARIO_DE_BORDO.md`.

## Ligações
**🔧 Alterou:** [[Regra - Recomeço do pedido]] · [[Gatilho - Recomeçar pedido]] · [[Painel Central Líder]] · [[MENSAGENS_CLIENTE]] · [[AGUARDANDO_ENTREGA]] · [[DigiSac]] · [[F2-1 Respostas do cliente]]

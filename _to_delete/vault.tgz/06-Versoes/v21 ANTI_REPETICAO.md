---
fluxo: Central Líder
versao: v21
data: 11/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__11-11_v21_ANTI_REPETICAO.json
base: v20
atualizado: 2026-11-11
tags: [versao]
---
# v21 ANTI_REPETICAO

**Data:** 11/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__11-11_v21_ANTI_REPETICAO.json` · **Base:** v20

Mesma mensagem do cliente entregue mais de uma vez pelo Digisac só é respondida uma vez. Antes de responder, o fluxo bloqueia a resposta repetida e limita a 1 resposta automática por mensagem do cliente. 13 nós novos, 1 alterado (433 nós). Testes simulados: 41/41; regressão recomeço 68/68, CPF 10/10, lembrete 42/42.

**Registro oficial:** ficha "11/11/2026 · v21 ANTI_REPETICAO" no capítulo 11 (diário de bordo) do manual do operador.

## Ligações
**🔧 Alterou:** [[Regra - Anti-repetição de mensagens]] · [[Gatilho - Resposta do cliente (DigiSac)]] · [[MENSAGENS_CLIENTE]] · [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]]

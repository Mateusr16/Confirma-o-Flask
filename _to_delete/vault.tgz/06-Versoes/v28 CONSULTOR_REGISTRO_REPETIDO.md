---
fluxo: Central Líder
versao: v28
data: 13/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__13-11_v28_CONSULTOR_REGISTRO_REPETIDO.json
base: v27
atualizado: 2026-11-13
tags: [versao]
---
# v28 CONSULTOR_REGISTRO_REPETIDO

**Data:** 13/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__13-11_v28_CONSULTOR_REGISTRO_REPETIDO.json` · **Base:** v27

Resultado já registrado pelo consultor não bloqueia mais uma nova consulta do mesmo pedido: **Só registrar resultado** (ou orientação + resultado) grava a planilha, conclui a consulta e pula a observação na intranet. Nó alterado: Processar ação do consultor. Testes simulados: 64/64.

**Por quê:** 13/11 — pedido 210471: registrado NAO_CONCORDA às 08:39, cliente escreveu às 08:42 e a consulta ficou presa com "O resultado deste pedido já foi registrado.".

## Ligações
[[Regra - Registro único do contato]] · [[v27 REGISTRO_CONSULTOR_SEM_INTRANET]]

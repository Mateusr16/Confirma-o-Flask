---
fluxo: Central Líder
versao: v20
data: 11/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__11-11_v20_RECOMECO_CONSULTA_CPF.json
base: v18
atualizado: 2026-11-11
tags: [versao]
---
# v20 RECOMECO_CONSULTA_CPF

**Data:** 11/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__11-11_v20_RECOMECO_CONSULTA_CPF.json` · **Base:** v18 (a v19 foi descartada)

Contato novo do recomeço salvo como "CPF - CLIENTE-(nome)"; botão de recomeço na tela Consultas da IA com aviso ao contato atual; CPF/CNPJ da intranet (15 dígitos) volta a entrar no nome dos contatos criados. 5 nós novos, 6 alterados (420 nós). Testes simulados: 68/68, 10/10 e painel 26/26.

**Registro oficial:** ficha "11/11/2026 · v20 RECOMECO_CONSULTA_CPF" no `DIARIO_DE_BORDO.md`.

## Ligações
**🔧 Alterou:** [[Regra - Recomeço do pedido]] · [[Gatilho - Recomeçar pedido]] · [[Painel Central Líder]] · [[DigiSac]] · [[MENSAGENS_CLIENTE]] · [[F1-3 Histórico e mensagem]]

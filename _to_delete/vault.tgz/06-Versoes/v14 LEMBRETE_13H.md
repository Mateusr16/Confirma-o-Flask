---
fluxo: Central Líder
versao: v14
data: 10/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__10-11_v14_LEMBRETE_13H.json
base: v13
atualizado: 2026-11-10
tags: [versao]
---
# v14 LEMBRETE_13H

**Data:** 10/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__10-11_v14_LEMBRETE_13H.json` · **Base:** v13

Nova rotina às 13:00 (seg–sex): lembrete curto a quem aceitou o template, recebeu a confirmação e não respondeu. 18 nós novos, nenhum alterado (381 nós). Testes: 42/42.

**Registro oficial:** ficha "10/11/2026 · v14 LEMBRETE_13H" no `DIARIO_DE_BORDO.md`.

## Ligações
**🔧 Alterou:** [[Regra - Lembrete de confirmação (13h)]] · [[F2-3 Automações agendadas]] · [[Gatilho - Lembrete de confirmação (13h)]] · [[MENSAGENS_CLIENTE]]

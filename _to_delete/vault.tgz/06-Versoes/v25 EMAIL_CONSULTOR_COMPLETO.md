---
fluxo: Central Líder
versao: v25
data: 12/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__12-11_v25_EMAIL_CONSULTOR_COMPLETO.json
base: v24
atualizado: 2026-11-12
tags: [versao]
---
# v25 EMAIL_CONSULTOR_COMPLETO

**Data:** 12/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__12-11_v25_EMAIL_CONSULTOR_COMPLETO.json` · **Base:** v24

O e-mail "Pedidos sem confirmação há 2 dias" passa a levar todos os pedidos do consultor no dia: novos (`ESCALAR`) e já encaminhados antes (`JA_ESCALADO`), num único e-mail, com a coluna "Situação". Novo filtro "Vai no e-mail ao consultor? (reincidência)" entre "Verificar resposta tardia" e "Lista de e-mails (consultor)". Testes simulados: 23/23.

**Por quê:** 12/11, Raynner recebeu e-mail só com o 209643 (Fabio); o 206407 (Arthur) era `JA_ESCALADO` e não ia no e-mail.

## Ligações
[[Regra - Reincidência sem retorno]] · [[E-mails de alerta]] · [[v24 VARREDURA_TARDIA]]

---
fluxo: Central Líder
versao: Versões
data: 05/11/2026
arquivo: "Claude outputs/Fluxo_Central_Lider__05-11_IA_v3.json (e REVISADO, OTIMIZADO, IA_v2)"
base: 30/10
atualizado: 2026-11-10
tags: [versao]
---
# Versões de 05-11

**Data:** 05/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__05-11_IA_v3.json (e REVISADO, OTIMIZADO, IA_v2)` · **Base:** 30/10

Adiamento permitido até 130 dias corridos após a data prevista (antes, 3 meses).

**Registro oficial:** ficha "05/11/2026 · versões de 05/11" no `DIARIO_DE_BORDO.md`.

## Ligações
**🔧 Alterou:** [[Regra - Adiamento e armazenagem]]

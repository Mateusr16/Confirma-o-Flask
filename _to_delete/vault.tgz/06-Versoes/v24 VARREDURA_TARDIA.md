---
fluxo: Central Líder
versao: v24
data: 12/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__12-11_v24_VARREDURA_TARDIA.json
base: v23
atualizado: 2026-11-12
tags: [versao]
---
# v24 VARREDURA_TARDIA

**Data:** 12/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__12-11_v24_VARREDURA_TARDIA.json` · **Base:** v23

Varredura de respostas tardias ao iniciar o n8n e às 08:05: lê no DigiSac as conversas de quem ficou sem retorno (último dia com encerramento) e dos abertos que o encerramento da tarde não pegou. Quem respondeu vai para ⏰ Respostas tardias, com o botão novo "✅ Registrar confirmado". 18 nós novos, 7 alterados (456 nós). Testes simulados: 75/75; regressões OK.

**Registro oficial:** ficha "12/11/2026 · v24 VARREDURA_TARDIA" no capítulo 11 (diário de bordo) do manual do operador.

## Ligações
**🔧 Alterou:** [[Gatilho - Varredura de respostas tardias]] · [[Regra - Resposta tardia]] · [[Regra - Encerramento sem retorno]] · [[Regra - Limpeza diária]] · [[SEM_CONFIRMACAO_DIARIO]] · [[MENSAGENS_CLIENTE]] · [[HISTORICO_PEDIDOS]] · [[DigiSac]] · [[Painel Central Líder]]

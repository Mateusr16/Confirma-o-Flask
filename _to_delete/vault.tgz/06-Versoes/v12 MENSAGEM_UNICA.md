---
fluxo: Central Líder
versao: v12
data: 10/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__10-11_v12_MENSAGEM_UNICA.json
base: v11
atualizado: 2026-11-10
tags: [versao]
---
# v12 MENSAGEM_UNICA

**Data:** 10/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__10-11_v12_MENSAGEM_UNICA.json` · **Base:** v11

Mesmo cliente com 2+ pedidos recebe 1 template e 1 mensagem; a resposta vale para todos os pedidos do grupo. Testes: 60/60.

**Registro oficial:** ficha "10/11/2026 · v12 MENSAGEM_UNICA" no `DIARIO_DE_BORDO.md`.

## Ligações
**🔧 Alterou:** [[Regra - Mensagem única por cliente]] · [[Regra - Adiamento e armazenagem]] · [[Regra - Encerramento sem retorno]] · [[F1-3 Histórico e mensagem]] · [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]]

---
fluxo: Central Líder
versao: v26
data: 12/11/2026
arquivo: Claude outputs/Fluxo_Central_Lider__12-11_v26_TRAVA_REGISTRO_UNICO.json
base: v25
atualizado: 2026-11-12
tags: [versao]
---
# v26 TRAVA_REGISTRO_UNICO

**Data:** 12/11/2026 · **Arquivo:** `Claude outputs/Fluxo_Central_Lider__12-11_v26_TRAVA_REGISTRO_UNICO.json` · **Base:** v25

Planilha e observação da intranet uma vez só por pedido (`dadosPedido.registroContato`); o consultor também não registra de novo. A IA marca `foraDaRegra` quando o cliente traz assunto que as regras não cobrem: base de conhecimento primeiro, consultor se a base não souber, sem resposta e sem gravar. Depois de adiamento, a IA usa a data nova. Espera de 60 s para juntar mensagens. Testes simulados: 91/91.

**Por quê:** 12/11 — Guilherme (2º registro "confirmou 22/03" depois de adiar para 30/03) e Danielle ("há itens que não estão na descrição" respondido com "Perfeito, obrigado pela confirmação").

## Ligações
[[Regra - Registro único do contato]] · [[Regra - Classificação da resposta do cliente]] · [[F2-1 Respostas do cliente]] · [[v25 EMAIL_CONSULTOR_COMPLETO]]

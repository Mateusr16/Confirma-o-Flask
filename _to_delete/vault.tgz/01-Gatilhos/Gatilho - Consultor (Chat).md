---
fluxo: Central Líder
gatilho: Central - Lider - Consultor (Chat)
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Central - Lider - Consultor (Chat)", "Processar ação do consultor", "É transferência?", "IA - Redigir resposta do consultor", "IA - Extrair aprendizado"]
tags: [gatilho, webhook]
---
# Gatilho - Consultor (Chat)

**Nó:** `Central - Lider - Consultor (Chat)`
**Quem dispara:** chat do consultor no [[Painel Central Líder]] (POST `central-lider-consultor`).
**O que acontece:** recebe a orientação do consultor: a IA redige a resposta ao cliente, ou o fluxo transfere o chamado, ou registra o resultado e alimenta a base de conhecimento.

## Trilha
- `Processar ação do consultor`: identifica a ação
- `É transferência?`: transferir ao responsável
- `IA - Redigir resposta do consultor`: redige a mensagem
- `IA - Extrair aprendizado`: gera pergunta/resposta para a base

## Ligações
**⬅️ Disparado por:** [[Painel Central Líder]]
**➡️ Passa por:** [[F2-2 Dúvidas e consultor]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[BASE_CONHECIMENTO]] · [[Planilha de confirmações]] · [[Intranet Líder]] · [[DigiSac]]

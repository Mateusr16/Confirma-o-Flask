---
fluxo: Central Líder
gatilho: DigiSac - Aguardar confirmação
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-12
nos: ["DigiSac - Aguardar confirmação", "Filtrar Mensagem", "Registrar mensagem do cliente", "Aguardar cliente terminar (60s)", "Escolher Linha", Switch]
tags: [gatilho, webhook]
---
# Gatilho - Resposta do cliente (DigiSac)

**Nó:** `DigiSac - Aguardar confirmação`
**Quem dispara:** DigiSac, a cada mensagem recebida do cliente (POST `digisac-resposta`).
**O que acontece:** inicia o Fluxo 2: grava a mensagem, espera o cliente terminar de digitar, acha o pedido e decide a resposta.

## Trilha
- `Filtrar Mensagem`: ignora o que não é mensagem de cliente
- `Registrar mensagem do cliente`: grava na MENSAGENS_CLIENTE
- `Aguardar cliente terminar (60s)`: agrupa mensagens seguidas (20 s até a v25)
- `Agrupar mensagens do cliente`: para a execução se a mesma mensagem (`messageId`) já chegou antes (v21)
- `Escolher Linha`: acha o pedido do contato
- `Switch`: separa aceite do template, resposta à confirmação e vigilância

## Ligações
**⬅️ Disparado por:** [[DigiSac]]
**📏 Regra:** [[Regra - Anti-repetição de mensagens]]
**➡️ Passa por:** [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]]
**🗄️ Lê/grava:** [[MENSAGENS_CLIENTE]] · [[AGUARDANDO_ENTREGA]] · [[Planilha de confirmações]] · [[Intranet Líder]]

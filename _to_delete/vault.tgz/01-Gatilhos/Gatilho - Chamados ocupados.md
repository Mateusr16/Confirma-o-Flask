---
fluxo: Central Líder
gatilho: Verificar chamados ocupados (30 min)
tipo: agendamento
frequencia: a cada 30 min
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Verificar chamados ocupados (30 min)", "Preparar retomada do envio", "Avaliar chamado (retomada)", "Enviar template (retomada)", "Marcar AGUARDANDO (retomada)"]
tags: [gatilho, agendamento]
---
# Gatilho - Chamados ocupados

**Nó:** `Verificar chamados ocupados (30 min)`
**Quem dispara:** agenda do n8n.
**O que acontece:** tenta de novo o envio dos pedidos parados em `AGUARDANDO_CHAMADO_LIVRE`.

## Trilha
- `Preparar retomada do envio`: lê a fila
- `Avaliar chamado (retomada)`: confere o chamado
- `Enviar template (retomada)`: envia se livre
- `Marcar AGUARDANDO (retomada)`: atualiza o status

## Ligações
**⬅️ Disparado por:** agenda
**➡️ Passa por:** [[F2-3 Automações agendadas]] · [[Regra - Chamado ocupado]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[DigiSac]]

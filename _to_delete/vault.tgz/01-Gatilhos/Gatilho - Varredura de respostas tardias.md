---
fluxo: Central Líder
gatilho: Varredura tardia - n8n iniciou / Varredura tardia (08:05)
tipo: agendamento
frequencia: "ao iniciar o n8n (espera 60 s) · 08:05 seg–sex"
versao_fluxo: v24
atualizado: 2026-11-12
nos: ["Varredura tardia - n8n iniciou", "Aguardar rede (varredura tardia)", "Varredura tardia (08:05)", "Selecionar contatos (varredura tardia)", "Buscar mensagens no DigiSac (varredura tardia)", "Analisar respostas (varredura tardia)", "Tipo de ação (varredura tardia)", "Gravar mensagem recuperada (varredura tardia)", "Gravar cartão tardio (varredura tardia)", "Marcar respondeu depois (varredura tardia)"]
tags: [gatilho, agendamento]
---
# Gatilho - Varredura de respostas tardias

**Nós:** `Varredura tardia - n8n iniciou` (n8n Trigger, evento "Instance started") e `Varredura tardia (08:05)` (agendamento seg–sex).
**Quem dispara:** o próprio n8n ao subir (computador ligado de manhã) e a agenda das 08:05, para o dia em que o computador já estava ligado. Só funciona com o fluxo publicado.
**O que acontece:** lê no DigiSac as conversas de quem ficou sem retorno e recupera o que o webhook não recebeu com o servidor desligado. Pode rodar várias vezes sem duplicar.

## Trilha
1. `Aguardar rede (varredura tardia)`: espera 60 s depois que o n8n sobe.
2. `Ler SEM_CONFIRMACAO (varredura tardia)`, `Ler AGUARDANDO_ENTREGA (varredura tardia)`, `Ler HISTORICO_PEDIDOS (varredura tardia)`, `Ler MENSAGENS_CLIENTE (varredura tardia)`: leem as tabelas uma vez.
3. `Selecionar contatos (varredura tardia)`: encerrados sem retorno no último dia com encerramento (segunda olha sexta) + pedidos de dias anteriores ainda em AGUARDANDO / DATA_ENVIADA / chamado ocupado (o encerramento da tarde não rodou). 1 item por contato.
4. `Buscar mensagens no DigiSac (varredura tardia)`: `GET /api/v1/messages` por contato, 100 por página, até 10 páginas; erro não para o fluxo.
5. `Analisar respostas (varredura tardia)` → `Tipo de ação (varredura tardia)`:
   - GRAVAR_MSG → `Gravar mensagem recuperada (varredura tardia)` (MENSAGENS_CLIENTE, horário original)
   - CARTAO → `Gravar cartão tardio (varredura tardia)` (PENDENTE_RESPOSTA_TARDIA) → `Marcar respondeu depois (varredura tardia)`
   - ENCERRAR → `Ler planilha de confirmações` (mesmo caminho do encerramento das 16:20, só com as linhas mandadas, dia do pedido)

## Ligações
**⬅️ Disparado por:** início do n8n · agenda
**➡️ Passa por:** [[Regra - Resposta tardia]] · [[Regra - Encerramento sem retorno]] · [[F2-3 Automações agendadas]] · [[Painel Central Líder]]
**🗄️ Lê/grava:** [[DigiSac]] · [[SEM_CONFIRMACAO_DIARIO]] · [[AGUARDANDO_ENTREGA]] · [[HISTORICO_PEDIDOS]] · [[MENSAGENS_CLIENTE]] · [[Planilha de confirmações]]

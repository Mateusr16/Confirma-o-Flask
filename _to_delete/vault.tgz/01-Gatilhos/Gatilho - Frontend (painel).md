---
fluxo: Central Líder
gatilho: Central - Lider - Frontend
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Central - Lider - Frontend", "Respond to Webhook"]
tags: [gatilho, webhook]
---
# Gatilho - Frontend (painel)

**Nó:** `Central - Lider - Frontend`
**Quem dispara:** navegador do operador (GET `central-lider`).
**O que acontece:** entrega a página HTML do painel, que está dentro do nó de resposta.

## Trilha
- `Respond to Webhook`: devolve o HTML do painel

## Ligações
**⬅️ Disparado por:** operador abrindo o endereço do painel
**➡️ Passa por:** [[Painel Central Líder]]
**🗄️ Lê/grava:** nenhum

---
fluxo: Central Líder
gatilho: disparar-fluxo-lider
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["disparar-fluxo-lider", "Evento inicial do disparo", "Separar dias anteriores", "Get row(s) in sheet", "Preparar Pedido"]
tags: [gatilho, webhook]
---
# Gatilho - Disparo pelo painel

**Nó:** `disparar-fluxo-lider`
**Quem dispara:** botão de disparo do [[Painel Central Líder]] (POST `disparar-fluxo-lider`).
**O que acontece:** inicia o Fluxo 1 inteiro: registra o disparo para a barra de progresso, faz a limpeza diária e processa os pedidos da planilha.

## Trilha
- `Evento inicial do disparo`: cria o `disparoId` do progresso
- `Separar dias anteriores`: limpeza diária
- `Get row(s) in sheet`: lê os pedidos da planilha
- `Preparar Pedido`: normaliza cada pedido

## Ligações
**⬅️ Disparado por:** [[Painel Central Líder]]
**➡️ Passa por:** [[F1-1 Coleta e validação]] · [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]]
**🗄️ Lê/grava:** [[FLUXO_STATUS]] · [[AGUARDANDO_ENTREGA]] · [[HISTORICO_PEDIDOS]] · [[Planilha de confirmações]]

---
fluxo: Central Líder
gatilho: When clicking ‘Execute workflow’
tipo: manual
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["When clicking ‘Execute workflow’", "Evento inicial do disparo"]
tags: [gatilho, manual]
---
# Gatilho - Execução manual

**Nó:** `When clicking ‘Execute workflow’`
**Quem dispara:** operador, pelo botão Execute workflow do editor do n8n.
**O que acontece:** mesmo caminho do disparo pelo painel. Usado para testes.

## Trilha
- `Evento inicial do disparo`: registra o disparo

## Ligações
**⬅️ Disparado por:** operador no editor do n8n
**➡️ Passa por:** [[F1-1 Coleta e validação]]
**🗄️ Lê/grava:** [[FLUXO_STATUS]]

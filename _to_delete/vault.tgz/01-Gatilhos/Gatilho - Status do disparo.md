---
fluxo: Central Líder
gatilho: Central - Lider - Status do disparo
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Central - Lider - Status do disparo", "Ler eventos do disparo", "Montar estado do disparo", "Responder status"]
tags: [gatilho, webhook]
---
# Gatilho - Status do disparo

**Nó:** `Central - Lider - Status do disparo`
**Quem dispara:** [[Painel Central Líder]], de tempos em tempos durante um disparo (GET `status-fluxo-lider`).
**O que acontece:** monta o progresso do disparo a partir dos eventos gravados.

> ⚠️ Sticky note no canvas: `Montar evento de status` e `Salvar evento de status` precisam ser os nós mais altos do canvas. Se descerem, o evento só é gravado no fim e a barra de progresso trava.

## Trilha
- `Ler eventos do disparo`: lê a FLUXO_STATUS
- `Montar estado do disparo`: calcula % e etapa
- `Responder status`: responde ao painel

## Ligações
**⬅️ Disparado por:** [[Painel Central Líder]]
**➡️ Passa por:** nenhuma etapa (só leitura)
**🗄️ Lê/grava:** [[FLUXO_STATUS]]

---
fluxo: Central Líder
gatilho: Central - Lider - API Pendências
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Central - Lider - API Pendências", Pendente_destino, "Filtro status", "Resposta Pendentes"]
tags: [gatilho, webhook]
---
# Gatilho - API Pendências

**Nó:** `Central - Lider - API Pendências`
**Quem dispara:** [[Painel Central Líder]] (GET `central-lider-pendencias`).
**O que acontece:** devolve ao painel os pedidos pendentes (destino, revisão, respostas tardias, consultor).

## Trilha
- `Pendente_destino`: lê a AGUARDANDO_ENTREGA
- `Filtro status`: separa por status
- `Resposta Pendentes`: responde em JSON

## Ligações
**⬅️ Disparado por:** [[Painel Central Líder]]
**➡️ Passa por:** nenhuma etapa (só leitura)
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]]

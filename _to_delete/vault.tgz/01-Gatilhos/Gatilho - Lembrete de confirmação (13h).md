---
fluxo: Central Líder
gatilho: Agendar lembrete de confirmação (13h)
tipo: agendamento
frequencia: "seg–sex 13:00"
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Agendar lembrete de confirmação (13h)", "Ler MENSAGENS_CLIENTE (lembrete)", "Filtrar lembrete elegível", "Avaliar chamado (lembrete)", "Reconferir pedido (lembrete)", "Enviar lembrete ao cliente", "Marcar lembrete enviado", "Registrar lembrete na conversa"]
tags: [gatilho, agendamento]
---
# Gatilho - Lembrete de confirmação (13h)

**Nó:** `Agendar lembrete de confirmação (13h)`
**Quem dispara:** agenda do n8n.
**O que acontece:** manda um lembrete curto a quem aceitou o template, recebeu a mensagem de confirmação e não respondeu nada (v14).

> Sticky note no canvas (`Nota - lembrete 13h`) resume as condições de envio.

## Trilha
- `Ler MENSAGENS_CLIENTE (lembrete)`: confere se o cliente já respondeu
- `Filtrar lembrete elegível`: escolhe quem recebe
- `Avaliar chamado (lembrete)`: só envia com o chamado comigo
- `Reconferir pedido (lembrete)`: relê o pedido antes de enviar
- `Enviar lembrete ao cliente`: envia, sem retry
- `Marcar lembrete enviado`: grava `lembreteConfirmacaoEm`
- `Registrar lembrete na conversa`: grava o lembrete como BOT na conversa

## Ligações
**⬅️ Disparado por:** agenda
**➡️ Passa por:** [[F2-3 Automações agendadas]] · [[Regra - Lembrete de confirmação (13h)]] · [[Regra - Chamado ocupado]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[MENSAGENS_CLIENTE]] · [[DigiSac]]

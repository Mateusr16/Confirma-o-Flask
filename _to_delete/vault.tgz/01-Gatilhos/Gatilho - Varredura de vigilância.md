---
fluxo: Central Líder
gatilho: Varredura de vigilância (10 min)
tipo: agendamento
frequencia: a cada 10 min
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Varredura de vigilância (10 min)", "Selecionar ações da varredura", "Fechar chamado (varredura)", "E-mail lembrete ao responsável"]
tags: [gatilho, agendamento]
---
# Gatilho - Varredura de vigilância

**Nó:** `Varredura de vigilância (10 min)`
**Quem dispara:** agenda do n8n.
**O que acontece:** fecha chamados cuja vigilância de 1 h venceu e cobra o consultor por consultas paradas.

## Trilha
- `Selecionar ações da varredura`: decide FECHAR, LIMPAR ou LEMBRAR
- `Fechar chamado (varredura)`: fecha no DigiSac
- `E-mail lembrete ao responsável`: cobra o consultor

## Ligações
**⬅️ Disparado por:** agenda
**➡️ Passa por:** [[F2-3 Automações agendadas]] · [[Regra - Vigilância e lembretes ao consultor]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[DigiSac]] · [[E-mails de alerta]]

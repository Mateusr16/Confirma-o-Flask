---
fluxo: Central Líder
gatilho: Central - Lider - Decisão de Envio
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Central - Lider - Decisão de Envio", "Buscar Revisão", "Decidir Revisão", Enviar?, "Timer envio Template"]
tags: [gatilho, webhook]
---
# Gatilho - Decisão de Envio

**Nó:** `Central - Lider - Decisão de Envio`
**Quem dispara:** botões da Revisão de envio e da tela de respostas tardias do [[Painel Central Líder]] (POST `central-lider-revisao`).
**O que acontece:** aplica a decisão do consultor (enviar, editar ou cancelar) e libera o envio do template.

## Trilha
- `Buscar Revisão`: lê a linha do pedido
- `Decidir Revisão`: aplica envio, edição ou cancelamento
- `Enviar?`: segue só se a decisão for enviar
- `Timer envio Template`: espera ~5 s entre envios (era ~10 s até a v12)

## Ligações
**⬅️ Disparado por:** [[Painel Central Líder]]
**➡️ Passa por:** [[F1-4 Liberação e envio]] · [[Regra - Edição da mensagem na Revisão]] · [[Regra - Resposta tardia]] · [[Regra - Chamado ocupado]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[SEM_CONFIRMACAO_DIARIO]] · [[DigiSac]]

---
fluxo: Central Líder
gatilho: Agendar encerramento pendências
tipo: agendamento
frequencia: "seg–qui 16:20 · sex 15:20"
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Agendar encerramento pendências", "Filtrar sem retorno elegível", "Fechar chamado Digisac", "Registrar sem retorno no Excel", "Registrar sem confirmação do dia"]
tags: [gatilho, agendamento]
---
# Gatilho - Encerramento de pendências

**Nó:** `Agendar encerramento pendências`
**Quem dispara:** agenda do n8n.
**O que acontece:** encerra quem não respondeu no dia: fecha o chamado, marca a planilha e anota o dia sem retorno. Em mensagem única (v12), grava em cada pedido do grupo.

## Trilha
- `Filtrar sem retorno elegível`: escolhe quem encerrar
- `Fechar chamado Digisac`: fecha 1 chamado por contato
- `Registrar sem retorno no Excel`: marca na planilha
- `Registrar sem confirmação do dia`: anota o dia

## Ligações
**⬅️ Disparado por:** agenda
**➡️ Passa por:** [[F2-3 Automações agendadas]] · [[Regra - Encerramento sem retorno]]
**🗄️ Lê/grava:** [[Planilha de confirmações]] · [[AGUARDANDO_ENTREGA]] · [[SEM_CONFIRMACAO_DIARIO]] · [[DigiSac]]

---
fluxo: Central Líder
gatilho: Erro no fluxo
tipo: erro
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Erro no fluxo", "Montar evento de erro", "E-mail alerta de erro"]
tags: [gatilho, erro]
---
# Gatilho - Erro no fluxo

**Nó:** `Erro no fluxo`
**Quem dispara:** o próprio n8n, quando uma execução falha.
**O que acontece:** grava o erro para o painel e manda e-mail de alerta.

## Trilha
- `Montar evento de erro`: evento para a barra de progresso
- `E-mail alerta de erro`: avisa por e-mail

## Ligações
**⬅️ Disparado por:** qualquer falha de execução
**➡️ Passa por:** nenhuma etapa
**🗄️ Lê/grava:** [[FLUXO_STATUS]] · [[E-mails de alerta]]

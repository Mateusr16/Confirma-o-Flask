---
fluxo: Central Líder
gatilho: Central - Lider - Resolver Pendência
tipo: webhook
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Central - Lider - Resolver Pendência", "Buscar Pendência", "Aplicar Destino Manual (Front)", "Marcar Pendência Resolvida", "Tratar individualmente?"]
tags: [gatilho, webhook]
---
# Gatilho - Resolver Pendência

**Nó:** `Central - Lider - Resolver Pendência`
**Quem dispara:** tela de pendências do [[Painel Central Líder]] (POST `central-lider-resolver`).
**O que acontece:** retoma um pedido parado em `PENDENTE_DESTINO` com o destino informado à mão e devolve o pedido ao Fluxo 1 a partir da rota.

## Trilha
- `Buscar Pendência`: lê a linha pendente
- `Aplicar Destino Manual (Front)`: aplica a cidade informada
- `Marcar Pendência Resolvida`: atualiza o status
- `Tratar individualmente?`: envio individual ou volta ao lote

## Ligações
**⬅️ Disparado por:** [[Painel Central Líder]]
**➡️ Passa por:** [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[Intranet Líder]]

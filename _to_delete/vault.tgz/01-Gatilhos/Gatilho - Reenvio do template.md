---
fluxo: Central Líder
gatilho: Agendar reenvio do template
tipo: agendamento
frequencia: "seg–sex 13:20"
versao_fluxo: v14
atualizado: 2026-11-10
nos: ["Agendar reenvio do template", "Filtrar reenvio elegível", "Avaliar chamado (reenvio)", "Reenviar template com botao", "Marcar template reenviado"]
tags: [gatilho, agendamento]
---
# Gatilho - Reenvio do template

**Nó:** `Agendar reenvio do template`
**Quem dispara:** agenda do n8n.
**O que acontece:** reenvia o template uma vez a quem ainda não aceitou.

## Trilha
- `Filtrar reenvio elegível`: escolhe quem recebe
- `Avaliar chamado (reenvio)`: confere se o chamado está livre
- `Reenviar template com botao`: envia
- `Marcar template reenviado`: marca para não repetir

## Ligações
**⬅️ Disparado por:** agenda
**➡️ Passa por:** [[F2-3 Automações agendadas]] · [[Regra - Reenvio do template]] · [[Regra - Chamado ocupado]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[DigiSac]]

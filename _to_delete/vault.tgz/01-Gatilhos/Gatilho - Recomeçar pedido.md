---
fluxo: Central Líder
gatilho: Central - Lider - Recomeçar Pedido
tipo: webhook
versao_fluxo: v20
atualizado: 2026-11-11
nos: ["Central - Lider - Recomeçar Pedido", "Validar recomeço", "Busca Digisac (recomeço)", "Criar Contato (recomeço)", "Montar recomeço", "Gravar recomeço (AGUARDANDO_ENTREGA)", "Conferir gravação (recomeço)", "Marcar recomeço na conversa", "Responder recomeço"]
tags: [gatilho, webhook]
---
# Gatilho - Recomeçar pedido

**Nó:** `Central - Lider - Recomeçar Pedido`
**Quem dispara:** botões 🔄 Recomeçar (tabela do Dashboard), 📱 Trocar número (Revisão) e 🔄 Recomeçar com outro contato (Consultas da IA, v20) do [[Painel Central Líder]] (POST `central-lider-recomecar`).
**O que acontece:** recomeça o atendimento do pedido com o mesmo número ou com outro. O pedido volta para a Revisão de Envio com o contato definido e a conversa zerada. Nada é enviado ao contato novo; o contato atual só recebe o aviso quando o consultor marca essa opção (v20).

## Trilha
- `Buscar pedido (recomeço)` → `Validar recomeço`: confere status, motivo, número e mensagem; recusa sem alterar nada
- `Tentativas busca (recomeço)` → `Busca Digisac (recomeço)` → `Avaliar busca (recomeço)`: procura o número novo nos 2 canais
- `Criar Contato (recomeço)` → `Avaliar criação (recomeço)`: cria o contato quando não existe
- `Outros pedidos do contato (recomeço)` → `Montar recomeço`: recusa se o número está em conversa ativa em outro pedido; monta o novo estado
- `Gravar recomeço (AGUARDANDO_ENTREGA)` → `Reler pedido (recomeço)` → `Conferir gravação (recomeço)`: grava só se o status não mudou e confere
- `Marcar recomeço na conversa`: marca RECOMECO na MENSAGENS_CLIENTE
- `Avisar contato anterior?` → `Enviar aviso ao contato anterior` → `Resultado do aviso (recomeço)` → `Aviso enviado?` → `Registrar aviso na conversa` (v20)
- `Atualizar contato (pedidos do grupo)`: acompanhantes da mensagem única
- `Resposta recomeço` → `Responder recomeço`: resposta ao painel

## Ligações
**⬅️ Disparado por:** [[Painel Central Líder]]
**➡️ Passa por:** [[Regra - Recomeço do pedido]] · [[F1-4 Liberação e envio]]
**🗄️ Lê/grava:** [[AGUARDANDO_ENTREGA]] · [[MENSAGENS_CLIENTE]] · [[DigiSac]]

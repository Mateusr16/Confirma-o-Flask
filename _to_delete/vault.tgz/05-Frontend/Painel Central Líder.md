---
fluxo: Central Líder
tipo: frontend
versao_fluxo: v20
atualizado: 2026-11-12
nos: ["Respond to Webhook"]
tags: [frontend]
---
# Painel Central Líder

**O que é:** página "Central Líder - Gestão de Pedidos e Entregas", servida pelo próprio n8n (o HTML fica dentro do nó `Respond to Webhook`).
**Quem usa:** consultor da central de relacionamento.

## Telas
- Dashboard Geral: funil por etapa, faixa de conciliação e taxa de confirmação (v11)
- Tabela de pedidos (todos os pedidos, abas Sem retorno e Saíram antes) e visão Por Responsável
- Disparo do fluxo com barra de progresso
- Pendências de destino (cidade/rota)
- Revisão de envio (com ✏️ Editar mensagem e 📱 Trocar número, v18)
- 🔄 Recomeçar na tabela de pedidos (v18): janela com novo número, nome e motivo
- ⏰ Respostas tardias (v24: "✅ Registrar confirmado" e "🚫 Não enviar (tratar por fora)"; reenviar o template em "Outras opções"; origem 🔎 varredura, 🌙 fora do horário e aviso quando o cliente não recebeu a data)
- Chat do consultor (Consultas da IA), com 🔄 Recomeçar com outro contato e aviso ao contato atual (v20)

## Contagem do Dashboard (v11)
- Cada pedido cai em um único grupo: total = saíram antes do envio + em preparação + aguardando envio + templates enviados.
- Enviados = concluídos + sem retorno + aguardando cliente + com humano.
- **Taxa de confirmação** (definida pelo Mateus em 10/11) = pedidos `CONCLUIDO` ÷ templates enviados. Transferidos (`ESCALADO`, `TRANSFERIDO`, `TRANSFERENCIA_MANUAL`), sem retorno e quem ainda aguarda não contam como finalizados.
- "Saíram antes do envio": 2 dias sem retorno (resumoIA começa com "Sem confirmação"), tratar individual e 🏬 `OUTLET` (v13).
- `AGUARDANDO_CHAMADO_LIVRE` conta em "Aguardando envio", não como cliente notificado.
- `AGRUPADO` acompanha o status do principal ("🔗 junto com 11-…") e não aparece nas telas de ação (v12).
- Status desconhecido → alerta na faixa de conciliação.

## Webhooks que chama
| Webhook (`path`) | Gatilho |
|---|---|
| `central-lider` | [[Gatilho - Frontend (painel)]] |
| `disparar-fluxo-lider` | [[Gatilho - Disparo pelo painel]] |
| `status-fluxo-lider` | [[Gatilho - Status do disparo]] |
| `central-lider-pendencias` | [[Gatilho - API Pendências]] |
| `central-lider-resolver` | [[Gatilho - Resolver Pendência]] |
| `central-lider-revisao` | [[Gatilho - Decisão de Envio]] |
| `central-lider-consultor` | [[Gatilho - Consultor (Chat)]] |
| `central-lider-recomecar` | [[Gatilho - Recomeçar pedido]] |

## Cuidados
- A cópia `index.html` na raiz do projeto é de 04/11 e está desatualizada (sem as telas da v8 em diante).
- O painel ainda não mostra quem recebeu o lembrete das 13h (pendência da v14). A versão que vale é a do nó `Respond to Webhook` do JSON atual.
- `index_BACKUP_antes_cards.html` é backup antigo.

## Ligações
**➡️ Chama:** [[Gatilho - Frontend (painel)]] · [[Gatilho - Disparo pelo painel]] · [[Gatilho - Status do disparo]] · [[Gatilho - API Pendências]] · [[Gatilho - Resolver Pendência]] · [[Gatilho - Decisão de Envio]] · [[Gatilho - Consultor (Chat)]] · [[Gatilho - Recomeçar pedido]]
**📏 Regras:** [[Regra - Edição da mensagem na Revisão]] · [[Regra - Resposta tardia]] · [[Regra - Mensagem única por cliente]] · [[Regra - Outlet]] · [[Regra - Recomeço do pedido]]

---
fluxo: Central Líder
tipo: referencia
atualizado: 2026-11-10
tags: [frontend, referencia]
---
# Páginas salvas da intranet

**O que é:** cópias salvas de páginas da intranet, usadas como referência para escrever os nós que leem o HTML.

- `situacao_pedidos.html` → página "Ordem de Expedição" / saldo de pedidos (lida por `Consultar Itens Solto`, `Consultar Itens Planejado` e `Cosultada Data Produto`).
- `listar_arq_pojetos.html` → lista de projetos postados (lida por `Consultar Projetos Postados`).

Não fazem parte do fluxo. Servem para comparar quando a intranet mudar de layout.

## Ligações
**⬅️ Referência de:** [[Intranet Líder]] · [[Regra - Planejados e data fictícia]]

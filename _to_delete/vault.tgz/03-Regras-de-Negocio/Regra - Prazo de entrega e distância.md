---
fluxo: Central Líder
regra: Prazo de entrega e distância
versao_criada: não registrado
versao_fluxo: v14
nos: ["Calcular Rota OSRM", "Tratar Distância", "Calcular Data de Entrega"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Prazo de entrega e distância

**Contexto:** A data informada ao cliente soma dias úteis de produção/expedição e da distância.

## Entradas
- `diasAdicionaisLider` (Number)
- distância em km (OSRM)
- `possui10DiasObservacao` (observação já tem os 10 dias)
- datas de entrega do pedido

## Condições críticas
- Distância > 100 km (interior) e sem os 10 dias na observação → +10 dias úteis.
- OSRM falhou → distância = linha reta × 1,35 (`DISTANCIA_ESTIMADA_FALLBACK_OSRM`).
- Sem coordenadas → rota `PENDENTE` (`ERRO_AO_CALCULAR_ROTA_OSRM`).
- Dias úteis: pula sábado, domingo e feriados nacionais (inclui Sexta-feira Santa e Consciência Negra).

## Saída
- `dataEntregaCalculada` (DD/MM/AAAA) = última data do pedido + dias úteis.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F1-2 Boleto e prazo]]
**📜 Histórico:** não registrado

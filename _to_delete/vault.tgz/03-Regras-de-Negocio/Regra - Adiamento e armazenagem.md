---
fluxo: Central Líder
regra: Adiamento e armazenagem
versao_criada: 05-11
versao_fluxo: v14
nos: ["Normalizar Categoria", "Adiamento válido?", "Alterar Data na Intranet - Adiamento", "Enviar Confirmação Adiamento"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Adiamento e armazenagem

**Contexto:** Cliente pode adiar a entrega dentro de um limite; desde a v10, toda resposta sobre adiamento avisa a regra de armazenagem (caso de 09/11, pedido 208435).

## Entradas
- data pedida pelo cliente
- data prevista do pedido
- histórico da conversa (quantas vezes a data já foi pedida)

## Condições críticas
- Limite: até 130 dias corridos após a data prevista (antes eram 3 meses).
- Mensagem única (v12): o limite conta da **menor** data prevista; o reagendamento automático só vale para data **depois da maior**. Data entre as previsões → oferece o responsável (`ADIAR_GRUPO_DATAS_DIFERENTES`). A alteração na intranet é feita em cada pedido do grupo.
- Sem data → pede a data (`PEDIR_DATA`); de novo (`PEDIR_DATA_NOVAMENTE`); depois de 2 vezes sem data, oferece o responsável.
- Só o mês → pede o dia (`PEDIR_DIA_DO_MES`).
- Além do limite, sem data prevista ou sem dia útil → `AGUARDANDO_DECISAO_RESPONSAVEL`.
- Aviso de armazenagem em DUVIDA_ADIAMENTO, nos pedidos de data e na confirmação final; não repete se o histórico já tiver o aviso (exceto na confirmação final).

## Saída
- Texto do aviso: "caso o pedido fique pronto antes da nova data, ele poderá ficar armazenado em nosso estoque por até 30 dias. Após esse prazo, será cobrada uma taxa de armazenamento."
- Adiamento válido → data alterada na intranet + confirmação ao cliente.

## Como foi testada
- v10: 10 cenários em Node, 10/10 OK; texto idêntico à v9 fora o aviso. v12: adiamento em grupo testado (60/60) e saída idêntica à v11 para pedido sozinho. Teste real pendente.

## Ligações
**⬅️ Aplicada em:** [[F2-1 Respostas do cliente]]
**📜 Histórico:** [[Versões de 05-11]] · [[v10 AVISO_ARMAZENAGEM]] · [[v12 MENSAGEM_UNICA]]

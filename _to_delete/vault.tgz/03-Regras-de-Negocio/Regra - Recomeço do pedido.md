---
fluxo: Central Líder
regra: Recomeço do pedido
versao_criada: v18
versao_fluxo: v20
nos: ["Validar recomeço", "Avaliar busca (recomeço)", "Montar recomeço", "Conferir gravação (recomeço)", "Enviar aviso ao contato anterior", "Preparar Tentativas Digisac", "Agrupar mensagens do cliente"]
atualizado: 2026-11-11
tags: [regra-negocio]
---
# Regra: Recomeço do pedido

**Contexto:** caso 11-210588 (11/11): o cliente pediu que todo o contato fosse feito com a esposa, em outro número. Também serve quando a IA se confunde na conversa.

## Entradas
- `avisoContatoAntigo` (v20, opcional): texto enviado ao contato atual; só com número novo
- `pedidoLider`, `novoTelefone` (opcional; em branco = mesmo número), `nomeContato` (opcional), `motivo` (obrigatório, mínimo 5 letras), `confirmarConcluido`

## Condições críticas
- Status permitidos: `PENDENTE_REVISAO`, `PENDENTE_RESPOSTA_TARDIA` (só com número novo), `AGUARDANDO_CHAMADO_LIVRE`, `AGUARDANDO`, `DATA_ENVIADA`, `AGUARDANDO_DECISAO_RESPONSAVEL`, `AGUARDANDO_CONSULTOR`, `ESCALADO`, `TRANSFERIDO`, `TRANSFERENCIA_MANUAL`, `SEM_RETORNO_CLIENTE`, `CANCELADO` e `CONCLUIDO` (com confirmação: intranet e planilha não são desfeitas).
- Recusa: `AGRUPADO` (recomece pelo principal), outlet, `BLOQUEADO`, `EM_PROCESSAMENTO` e demais status; pedido sem mensagem; pedido duplicado na tabela; telefone que não é celular.
- Número novo: busca nos 2 canais pelos últimos 8 dígitos (como `Preparar Tentativas Digisac`), preferindo o número exato e depois o canal 1. Não achou → cria o contato com o nome "CPF/CNPJ - CLIENTE-(nome)", ex.: "02791934677 - RAFI GREEN-(Anete)" (v20). Erro em qualquer busca → não cria e não altera nada.
- Se o número já está em conversa ativa em outro pedido (AGUARDANDO, DATA_ENVIADA, decisão do responsável, consultor, chamado ocupado, em processamento ou vigilância aberta), o fluxo DEVE recusar.
- A gravação só acontece se o status ainda for o lido no início; depois o pedido é relido e conferido.

## Saída
- Status `PENDENTE_REVISAO` com `contactId`, `phone` e `serviceId` novos; `categoria`, `resposta`, `respostaData`, `resumoIA`, `respondidoEm`, `enviadoEm`, `vigiaAte` e `chatConsultor` zerados. O estado anterior vai para `dadosPedido.recomecos`.
- Com o nome informado, "Olá, <cliente>!" vira "Olá, <nome>!" (original em `mensagemAntesRecomeco`).
- Marca papel `RECOMECO` na [[MENSAGENS_CLIENTE]]: `Agrupar mensagens do cliente` só usa o histórico depois dela.
- Aviso ao contato atual (v20): sai pelo DigiSac só depois que o recomeço é gravado e conferido, e fica registrado como BOT na conversa dele. Na tela Consultas da IA vem marcado com texto pronto: "Combinado, <cliente>! A partir de agora vamos tratar a entrega do pedido nº *X* com <nome> pelo número <número>. Obrigado!". Se falhar, o recomeço vale e o painel pede para avisar à mão.
- O chamado do número antigo não é fechado.

## Como foi testada
- Simulado: `testes_v20/teste_recomeco.js` 68/68 OK; painel `teste_painel_v20.py` 26/26 OK. Real: pendente (11-210588).

## Ligações
**⬅️ Aplicada em:** [[Gatilho - Recomeçar pedido]] · [[F2-1 Respostas do cliente]]
**📜 Histórico:** [[v18 RECOMECAR_PEDIDO]] · [[v20 RECOMECO_CONSULTA_CPF]]

---
fluxo: Central Líder
regra: Reincidência sem retorno
versao_criada: não registrado
versao_fluxo: v25
nos: ["Verificar reincidência sem retorno", "Reincidente sem retorno?", "Vai no e-mail ao consultor? (reincidência)", "Montar e-mail ao consultor (reincidência)", "Enviar e-mail ao consultor (reincidência)", "Marcar escalado (sem confirmação)", "Marcar já encaminhado (AGUARDANDO_ENTREGA)"]
atualizado: 2026-11-12
tags: ["regra-negocio"]
---
# Regra - Reincidência sem retorno

**Contexto:** Cliente que não responde há dias não deve receber o template de novo; o consultor assume.

## Entradas
- SEM_CONFIRMACAO_DIARIO: `pedidoLider`, `dataRef`, `status`

## Condições críticas
- 2 ou mais dias diferentes sem retorno (antes de hoje) → `ESCALAR`: e-mail ao consultor, status `ESCALADO`.
- Já escalado → grava `ESCALADO` na AGUARDANDO_ENTREGA com o motivo no `resumoIA` ("Sem confirmação em N dias…"). Até a v10 o pedido ficava preso em `EM_PROCESSAMENTO` (corrigido na v11).
- E-mail ao consultor (v25): um por consultor, com todos os pedidos `ESCALAR` e `JA_ESCALADO` do dia (coluna "Situação": 1º aviso / Já encaminhado antes). Até a v24 só os `ESCALAR` entravam (caso Raynner 12/11: 206407 ficou fora do e-mail).
- Dias com `RESPONDEU_DEPOIS` ou `RESPOSTA_TARDIA_TRATADA` não contam.
- Rodar o encerramento 2x no mesmo dia conta como 1 dia.

## Saída
- `acaoReincidencia`: `NORMAL`, `ESCALAR`, `JA_ESCALADO`.

## Como foi testada
- 32 testes simulados da v8 (inclui a regra de não contar respostas tardias). Contagem do painel com os reincidentes: 9/9 OK nos testes da v11.

## Ligações
**⬅️ Aplicada em:** [[F1-3 Histórico e mensagem]]
**📜 Histórico:** [[v8 RESPOSTA_TARDIA]] · [[v11 DASHBOARD_CONTAGEM]] · [[v25 EMAIL_CONSULTOR_COMPLETO]]

---
fluxo: Central Líder
regra: Lembrete de confirmação (13h)
versao_criada: v14
versao_fluxo: v14
nos: ["Agendar lembrete de confirmação (13h)", "Ler MENSAGENS_CLIENTE (lembrete)", "Filtrar lembrete elegível", "Avaliar chamado (lembrete)", "Reconferir pedido (lembrete)", "Pode enviar lembrete?", "Enviar lembrete ao cliente", "Marcar lembrete enviado", "Registrar lembrete na conversa"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Lembrete de confirmação (13h)

**Contexto:** Aumentar a taxa de confirmação: o cliente do pedido 11-209940 aceitou o template, recebeu a mensagem às 09:10 e ficou em silêncio; o lembrete manual das 13:05 teve resposta na hora.

## Entradas
- AGUARDANDO_ENTREGA: `status`, `categoria`, `respondidoEm`, `dadosPedido.lembreteConfirmacaoEm`
- MENSAGENS_CLIENTE: mensagens do cliente depois da confirmação
- chamado aberto do contato no DigiSac

## Condições críticas
- Horário: seg–sex 13:00 (antes do reenvio das 13:20).
- Só envia se: status `DATA_ENVIADA`; `categoria` vazia; nenhuma mensagem do cliente depois da confirmação; confirmação enviada há 1 h a 23 h (janela de 24 h do WhatsApp); lembrete ainda não enviado; nenhum outro pedido do contato em atendimento.
- Chamado tem que estar comigo (fechado, ocupado, na fila ou erro = não envia).
- O pedido é reconferido na tabela logo antes do envio.
- Leitura das mensagens falhou → ninguém recebe. Envio sem retry (evita lembrete em dobro).
- Um lembrete por pedido e por contato.

## Saída
- Texto: "Boa tarde, <nome>! Podemos confirmar a data de entrega do pedido nº *X*?". Na 1ª confirmação de planejados: "Pode nos confirmar o recebimento da mensagem sobre o seu pedido nº *X*?". Em mensagem única, cita todos os pedidos.
- Grava `lembreteConfirmacaoEm` e `lembreteConfirmacaoTexto` no `dadosPedido` e registra o lembrete na MENSAGENS_CLIENTE (papel BOT).
- Status continua `DATA_ENVIADA`: a resposta segue para a IA normalmente.

## Como foi testada
- `testes_v14/teste_lembrete.js`: 42/42 OK; regressão do outlet 23/23. Teste real pendente (pedido 97680: aceitar o template antes das 12:00 e não responder).

## Ligações
**⬅️ Aplicada em:** [[F2-3 Automações agendadas]] · [[F2-1 Respostas do cliente]]
**📜 Histórico:** [[v14 LEMBRETE_13H]]

---
fluxo: Central Líder
regra: Trava de boleto e boleto 50%
versao_criada: v5
versao_fluxo: v14
nos: ["Conferir Boletos", "Tratar Conferência Boleto", ANALISAR, "Analisar 50% do Pedido", "Calcular Nova Data Boleto 50%", "Alterar Data - Boleto 50%", "Bloquear pedido (pendência de boleto)", "Pedido com pendência de boleto?"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Trava de boleto e boleto 50%

**Contexto:** Pedido com boleto pendente não pode ser confirmado com o cliente.

## Entradas
- página de pagamentos x entrega da intranet
- `motivoPlanilha` (pedido que já caiu em BOLETO/50% antes)
- parcelas e vencimentos do pedido

## Condições críticas
- Pedido com `ANALISAR` na conferência → regra dos 50%: acha a parcela que completa 50% do valor e calcula a nova data em dias úteis.
- Pedido que já caiu em BOLETO na planilha → `BOLETO_JA_TRATADO`: continua travado, mesmo que a intranet não mostre mais ANALISAR.
- Pedido com pendência de boleto NUNCA vai para confirmação.
- Falha ao calcular a nova data → e-mail de alerta.

## Saída
- Status do boleto: `OK`, `ANALISAR`, `NAO_ENCONTRADO`, `ERRO_CONSULTA`, `BOLETO_JA_TRATADO`.
- Data alterada na intranet, observação registrada e planilha marcada "Boleto 50%".

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]]
**📜 Histórico:** [[v5 TRAVA_BOLETO]]

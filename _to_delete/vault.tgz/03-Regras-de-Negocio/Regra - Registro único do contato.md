---
fluxo: Central Líder
regra: Registro único do contato
versao_criada: v26
versao_fluxo: v26
nos: ["Classificar Resposta Sheet", "Montar registro único", "Gravar registro único (AGUARDANDO_ENTREGA)", "Normalizar Categoria", "Preparar contexto IA", "Processar ação do consultor", "Resumo do registro (consultor)", "Finalizar pedido (consultor)"]
atualizado: 2026-11-12
tags: ["regra-negocio"]
---
# Regra - Registro único do contato

**Contexto:** em 12/11 o Guilherme (11-210754 + 11-210901) adiou para 30/03/2027 às 10:15 (registro 23223211) e, com as mensagens seguintes ("não quero pagar taxa", "já está pronto", "estava em exposição"), a IA confirmou a data antiga e gravou um 2º registro "CONFIRMOU 22/03/2027" (23223218). Decisão do Mateus: a intranet é preenchida uma vez só e o consultor não corrige registro feito.

## Entradas
- `dadosPedido.registroContato` na [[AGUARDANDO_ENTREGA]]: `em`, `origem` (IA ou CONSULTOR), `categoria`/`resultado`, `dataEntrega`, `pedidos`

## Condições críticas
- O 1º registro (planilha G/H/I + observação de contato na intranet) grava a marca. Pela IA: `Montar registro único` (paralelo à planilha). Pelo consultor: `Resumo do registro (consultor)` → `Finalizar pedido (consultor)`.
- Com a marca: `Classificar Resposta Sheet` não grava; `Normalizar Categoria` não altera data; `Processar ação do consultor` recusa "Só registrar resultado".
- Depois do registro: confirmação repetida → sem resposta; adiantar ou dúvida de adiamento → resposta padrão; nova data ou recusa → consultor (`ALTERAR_REGISTRO`); assunto fora das regras → base ou consultor.
- A `dataEntrega` da marca é a referência da IA (data nova depois de adiamento).
- As linhas "PRAZO ... ALTERADO" criadas pela intranet (uma por item) ao alterar a data são normais e não contam.
- Sem retorno (NÃO / SEM RETORNO CLIENTE) não grava observação e não cria a marca.

## Saída
- Log da execução: `[registro único] pedido <nº> já registrado em <data> (...); nada gravado de novo`.

## Como foi testada
- `testes_v26/teste_registro_unico.js`: 91/91 OK (simulado). Teste real pendente.

## Ligações
**⬅️ Aplicada em:** [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]]
**📜 Histórico:** [[v26 TRAVA_REGISTRO_UNICO]]

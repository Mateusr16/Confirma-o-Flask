---
fluxo: Central Líder
regra: Encerramento sem retorno
versao_criada: não registrado
versao_fluxo: v14
nos: ["Filtrar sem retorno elegível", "Fechar chamado Digisac", "Registrar sem retorno no Excel", "Marcar encerrado no n8n", "Registrar sem confirmação do dia"]
atualizado: 2026-11-12
tags: ["regra-negocio"]
---
# Regra - Encerramento sem retorno

**Contexto:** Fechar no fim do dia os atendimentos em que o cliente não deu retorno.

## Entradas
- planilha: colunas `CONFIRMADO`, `MOTIVO`, `DATA ENVIO CONF.`
- AGUARDANDO_ENTREGA: `status`, `contactId`

## Condições críticas
- Horário: seg–qui 16:20, sex 15:20.
- Encerra só `AGUARDANDO` (não aceitou o template) e `DATA_ENVIADA` (não respondeu a confirmação) com as 3 colunas da planilha vazias.
- Nunca encerra `TRANSFERIDO`, `TRANSFERENCIA_MANUAL`, `ESCALADO`.
- Não fecha o chamado de contato com conversa ativa com consultor/responsável.
- Um fechamento por contato, mesmo com vários pedidos.
- Mensagem única: o "sem retorno" é gravado em todos os pedidos do grupo.
- v24: se o encerramento da tarde não rodou (computador desligado), a [[Gatilho - Varredura de respostas tardias]] encerra na manhã seguinte os pedidos de dias anteriores sem resposta, pelo mesmo caminho, com o dia do pedido em `dataRef` e o resumo "(varredura da manhã ...)".

## Saída
- Chamado fechado, planilha marcada sem retorno, dia anotado na SEM_CONFIRMACAO_DIARIO.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F2-3 Automações agendadas]]
**📜 Histórico:** [[v23 OCUPADO_SEM_RETORNO]] · [[v24 VARREDURA_TARDIA]]

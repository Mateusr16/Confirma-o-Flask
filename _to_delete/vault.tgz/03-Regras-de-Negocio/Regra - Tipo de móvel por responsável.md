---
fluxo: Central Líder
regra: Tipo de móvel por responsável
versao_criada: não registrado
versao_fluxo: v14
nos: ["Classificar Tipo de Móvel", "Separ produtos", "Responsável sem tipo de móvel"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Tipo de móvel por responsável

**Contexto:** A mensagem muda conforme o tipo de móvel, e o tipo sai do responsável pelo pedido.

## Entradas
- `RESPONSÁVEL` da planilha

## Condições críticas
- Responsável na lista de planejados → `Planejados`.
- Responsável na lista de móveis soltos → `Moveis soltos`.
- Fora das listas → sem tipo (tratado à parte).

## Saída
- `tipoMovel` usado para escolher a mensagem.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]]
**📜 Histórico:** não registrado

---
fluxo: Central Líder
regra: Anti-repetição de mensagens
versao_criada: v21
versao_fluxo: v21
nos: ["Agrupar mensagens do cliente", "Anti-repetição (resposta fixa)", "Anti-repetição (mensagem programada)", "Anti-repetição (resposta da base)", "Anti-repetição (adiamento)", "Anti-repetição: ler conversa (…)", "Anti-repetição: pode enviar? (…)"]
atualizado: 2026-11-11
tags: ["regra-negocio"]
---
# Regra - Anti-repetição de mensagens

**Contexto:** em 11/11, entre 13:18 e 13:22, durante uma instabilidade, um cliente recebeu 4 vezes a mesma resposta ("Entendo. A data que informamos…") e depois "Perfeito, obrigado pela confirmação!". Até a v20, cada entrega do mesmo evento pelo Digisac era respondida.

## Entradas
- Webhook `digisac-resposta`: `messageId` da mensagem do cliente
- MENSAGENS_CLIENTE: falas do contato (`papel` CLIENTE, BOT e marca RECOMECO), relidas logo antes de cada envio

## Condições críticas
- **Entrada:** se já existe linha CLIENTE com o mesmo `messageId` gravada antes, a execução para no `Agrupar mensagens do cliente`. Mensagens sem id (`sem-id-…`) não são checadas.
- **Saída:** antes da resposta fixa, da resposta da base, da confirmação de adiamento e da mensagem programada, não envia se:
  - a última fala BOT do contato (últimas 24 h) tem o mesmo texto (ignora espaços, maiúsculas e `*`) → `MENSAGEM_REPETIDA`;
  - já existe fala BOT depois da última mensagem do cliente (últimos 30 min) → `RESPOSTAS_DEMAIS` (máximo 1 resposta automática por mensagem ou rajada do cliente).
- O que vem antes da última marca RECOMECO não conta.
- Se a leitura da conversa falhar, envia normalmente (a trava da entrada continua valendo).

## Saída
- Bloqueado: o envio não sai e os passos seguintes desse caminho não rodam; o log da execução mostra `[anti-repetição] envio bloqueado (<origem>) contato <id>: <motivo>`.
- Liberado: o item segue sem alteração para o envio.

## Fora da regra (pendente)
- Encerrar sem transferência, Resposta ambígua: confirmar decisão, Confirmar encaminhamento ao cliente, Informar encaminhamento manual pendente: só a trava da entrada.
- Nova tentativa dos envios ao Digisac (2 tentativas, 4 s) continua ligada.

## Como foi testada
- `testes_v21/teste_anti_repeticao.js`: 41/41 OK, com o caso de 11/11 simulado (1 resposta em vez de 5). Teste real pendente.

## Ligações
**⬅️ Aplicada em:** [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[Gatilho - Resposta do cliente (DigiSac)]]
**📜 Histórico:** [[v21 ANTI_REPETICAO]]

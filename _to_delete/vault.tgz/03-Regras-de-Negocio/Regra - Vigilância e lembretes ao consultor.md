---
fluxo: Central Líder
regra: Vigilância e lembretes ao consultor
versao_criada: não registrado
versao_fluxo: v14
nos: ["Abrir vigilância (1h)", "Escolher Linha", "Selecionar ações da varredura", "Fechar chamado (varredura)", "E-mail lembrete ao responsável"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Vigilância e lembretes ao consultor

**Contexto:** Depois de concluir, o chamado fica aberto 1 h para o cliente ainda poder falar; consultas paradas são cobradas.

## Entradas
- `vigiaAte`
- `status`
- `chatConsultor` (histórico do chat)

## Condições críticas
- Vigilância de 1 h após a conclusão; prorrogada se o cliente responder.
- Vencida com `CONCLUIDO` → fecha o chamado (FECHAR); outro status → só limpa (LIMPAR).
- `AGUARDANDO_CONSULTOR` há mais de 60 min → e-mail de lembrete; repete a cada 3 h; máximo 4.

## Saída
- Chamado fechado ou lembrete enviado; registro no chat.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[F2-3 Automações agendadas]]
**📜 Histórico:** não registrado

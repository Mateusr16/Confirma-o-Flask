---
fluxo: Central Líder
regra: Edição da mensagem na Revisão
versao_criada: v9
versao_fluxo: v14
nos: ["Decidir Revisão", "Respond to Webhook"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Edição da mensagem na Revisão

**Contexto:** Permitir ajustar a mensagem antes do envio (caso do pedido 11-209865).

## Entradas
- `mensagemEditada` (texto vindo do botão ✏️ Editar mensagem)

## Condições críticas
- Texto editado diferente do padrão → substitui a mensagem; vai depois do aceite do template.
- Vale no envio individual, em lote e com chamado ocupado.
- Mensagem vazia é bloqueada; o vídeo é mantido.

## Saída
- `mensagemOriginal` guarda o texto padrão.

## Como foi testada
- 32 testes da v8 + 7 novos OK; painel testado no Chrome.

## Ligações
**⬅️ Aplicada em:** [[F1-4 Liberação e envio]] · [[Painel Central Líder]]
**📜 Histórico:** [[v9 EDITAR_MENSAGEM]]

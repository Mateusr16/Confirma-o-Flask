---
fluxo: Central Líder
regra: Chamado ocupado
versao_criada: v7
versao_fluxo: v14
nos: ["Avaliar chamado (envio)", "Chamado livre? (envio)", "Marcar aguardando chamado livre", "Avaliar chamado (reenvio)", "Avaliar chamado (retomada)"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Chamado ocupado

**Contexto:** O fluxo "roubou" o chamado de outro atendente ao enviar o template.

## Entradas
- chamados abertos do contato no DigiSac
- usuário DigiSac do próprio fluxo (configurado no nó)

## Condições críticas
- Só envia se não houver chamado aberto, ou se o chamado aberto já for do próprio usuário.
- Chamado na fila, sem atendente, também bloqueia.
- Qualquer dúvida (erro na API, resposta estranha) = NÃO envia.
- Bloqueado → `AGUARDANDO_CHAMADO_LIVRE`; nova tentativa a cada 30 min.

## Saída
- Envio do template só com chamado livre.

## Como foi testada
- não registrado (revisão técnica de 06/11 em REVISAO_Fluxo_06-11_v7.md).

## Ligações
**⬅️ Aplicada em:** [[F1-4 Liberação e envio]] · [[F2-3 Automações agendadas]]
**📜 Histórico:** [[v7 CHAMADO_OCUPADO]]

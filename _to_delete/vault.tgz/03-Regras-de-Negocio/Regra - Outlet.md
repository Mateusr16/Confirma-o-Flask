---
fluxo: Central Líder
regra: Outlet
versao_criada: v13
versao_fluxo: v14
nos: ["Consultar estoque (outlet)", "Verificar outlet", "É outlet?", "Montar registro (outlet)", "Marcar outlet (AGUARDANDO_ENTREGA)", "Sheet – Outlet", "Tem data? (outlet)", "Observação Intranet (outlet)"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Outlet

**Contexto:** Pedido de outlet é retirado direto na loja: não faz sentido pedir confirmação de data ao cliente (ex.: 11-209534). Regra definida pelo Mateus em 10/11.

## Entradas
- página vdp/situacao_pedidos.php: colunas `Qtde`/`Quantidade` e `Est`/`Estoque`
- linhas da empresa 11 do próprio pedido

## Condições críticas
- Outlet = **todos** os itens com Quantidade = Estoque.
- Linhas com quantidade zero (ex.: IPI) não contam; linhas "(02)-…" de transferência são ignoradas.
- Estoque maior que a quantidade **não** conta como outlet.
- Página fora do ar, sem as colunas ou pedido não encontrado → segue o fluxo normal (motivo em `motivoOutlet`).
- Fica depois da conferência de boleto: pedido com boleto pendente nunca chega aqui.

## Saída
- Status `OUTLET` na AGUARDANDO_ENTREGA; planilha SIM / CONFIRMADO / data.
- Aviso na intranet com a menor data de prazo dos itens e a observação "PEDIDO OUTLET (RETIRADA NA LOJA): QUANTIDADE IGUAL AO ESTOQUE EM TODOS OS ITENS. CONFIRMACAO REGISTRADA AUTOMATICAMENTE, SEM CONTATO COM O CLIENTE." Sem data, o aviso não é enviado.
- Nenhuma mensagem vai ao cliente. No painel conta em "Saíram antes do envio" (🏬 Outlet).

## Como foi testada
- `testes_v13/teste_outlet.js`: 23/23 OK, com a página real do pedido 11-209534. Teste real pendente. Se `motivoOutlet` vier `PAGINA_SEM_COLUNA_ESTOQUE`, a página mudou o cabeçalho.

## Ligações
**⬅️ Aplicada em:** [[F1-2 Boleto e prazo]] · [[Painel Central Líder]]
**📜 Histórico:** [[v13 OUTLET]]

---
fluxo: Central Líder
regra: Resposta tardia
versao_criada: v8
versao_fluxo: v24
nos: ["Verificar resposta tardia", "É resposta tardia?", "Marcar respondeu depois (SEM_CONFIRMACAO)", "Decidir Revisão", "Liberar resposta tardia", "Marcar resposta tardia tratada", "Selecionar contatos (varredura tardia)", "Analisar respostas (varredura tardia)", "Gravar cartão tardio (varredura tardia)", "Processar ação do consultor", "Marcar resposta tardia tratada (registro)", "Separar dias anteriores"]
atualizado: 2026-11-12
tags: ["regra-negocio"]
---
# Regra - Resposta tardia

**Contexto:** Caso de 06/11: cliente respondeu às 15:28, depois do encerramento das 15:20, e a v7 ignorou a mensagem. Caso de 11/11 (v24): cliente encerrada às 16:21 respondeu "Sim" às 21:01 com o servidor desligado; o webhook não recebeu e a v23 não achava.

## Entradas
- último encerramento sem retorno do pedido (SEM_CONFIRMACAO_DIARIO)
- mensagens do cliente depois do encerramento (MENSAGENS_CLIENTE)
- v24: conversa do contato lida direto no DigiSac (`/api/v1/messages`) pela [[Gatilho - Varredura de respostas tardias]]

## Condições críticas
- Cliente mandou mensagem depois do encerramento → `PENDENTE_RESPOSTA_TARDIA`, tela ⏰ Respostas tardias.
- Consultor escolhe: enviar sem texto = `FLUXO_NORMAL`; enviar com texto = `RESPOSTA_DIFERENTE` (template primeiro, depois o texto, sem vídeo); cancelar = `NAO_ENVIAR`.
- Quem respondeu tarde não conta como dia sem retorno.
- v24: a varredura (ao iniciar o n8n e às 08:05) olha os encerrados do último dia com encerramento; segunda olha sexta.
- v24: conta como resposta a mensagem do cliente depois do encerramento OU a que o n8n nunca recebeu depois do envio (servidor fora). A que o n8n já tinha recebido antes do encerramento não conta.
- v24: pedido de dia anterior ainda aberto (encerramento da tarde não rodou): com resposta → cartão `NAO_ENCERRADO`; sem resposta → encerrado como sem retorno.
- v24: só vira cartão se o pedido estiver parado (SEM_RETORNO_CLIENTE / PENDENTE_REVISAO / PENDENTE_RESPOSTA_TARDIA, ou aberto de ontem); pedido já em andamento hoje não é mexido. Mensagem única: 1 cartão no pedido principal. Linha já arquivada é recriada do HISTORICO_PEDIDOS.
- v24: falha na consulta ao DigiSac → nada é feito com aquele contato (nem encerrado).
- v24: botão "✅ Registrar confirmado" = `REGISTRAR` / `CONFIRMADO` pelo webhook do consultor: planilha SIM / CONFIRMADO, observação na intranet, CONCLUIDO, diário `RESPOSTA_TARDIA_TRATADA`; nada é enviado e o chamado não é fechado. Reenviar o template ficou em "Outras opções".
- v24: PENDENTE_RESPOSTA_TARDIA não é arquivado pela limpeza diária.

## Saída
- Template sempre sai primeiro; a decisão já dispara o envio.

## Como foi testada
- v24: `testes_v24/teste_varredura_tardia.js` 75/75 OK (simulado). Real: pendente.
- 32 testes simulados OK. Teste real (09/11) não detectou o caso: a mensagem do cliente era de 06/11 e a MENSAGENS_CLIENTE só grava desde 09/11, 08:43. (A causa "falta da coluna `ts`" foi descartada em 10/11: a coluna existe.)

## Ligações
**⬅️ Aplicada em:** [[F1-3 Histórico e mensagem]] · [[F1-4 Liberação e envio]]
**📜 Histórico:** [[v8 RESPOSTA_TARDIA]] · [[v24 VARREDURA_TARDIA]]
**⏰ Gatilho:** [[Gatilho - Varredura de respostas tardias]]

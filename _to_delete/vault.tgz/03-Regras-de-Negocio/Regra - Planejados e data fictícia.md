---
fluxo: Central Líder
regra: Planejados e data fictícia
versao_criada: v6
versao_fluxo: v14
nos: ["Verificar Planejado Data Absurda", "Pular boleto?", "Montar Mensagem Planejados"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Planejados e data fictícia

**Contexto:** Planejados entram com data fictícia na intranet até o projeto ser postado. Há duas confirmações: a 1ª (sem projeto) e a 2ª (com projeto e data real).

## Entradas
- `RESPONSÁVEL` (lista fixa de responsáveis de planejados no nó)
- datas de entrega do pedido
- lista de projetos postados (listar_arq_pojetos.php)

## Condições críticas
- Planejado com data de ano ≥ 2030 → `pularBoleto` (não confere boleto).
- 1ª confirmação não entra na mensagem única (texto e vídeo próprios).
- 1ª confirmação: data fictícia (ano ≥ 2040, ex.: 01/12/2040) e/ou item de ambiente sem projeto postado. Na planilha: SIM / CONFIRMADO; na intranet a data fictícia é mantida e entra a observação padrão de 1ª confirmação.
- 2ª confirmação: todos os itens de ambiente com projeto postado → mensagem com data e produtos.
- Só conta como projeto arquivo .zip, .rar ou .7z.
- Lista de projetos não carregou → pedido bloqueado para revisão.

## Saída
- Mensagem de 1ª ou 2ª confirmação.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F1-1 Coleta e validação]] · [[F1-2 Boleto e prazo]] · [[F1-3 Histórico e mensagem]]
**📜 Histórico:** [[v6 1A_CONFIRMACAO]]

---
fluxo: Central Líder
regra: Reenvio do template
versao_criada: não registrado
versao_fluxo: v14
nos: ["Filtrar reenvio elegível", "Reenviar template com botao", "Marcar template reenviado"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Reenvio do template

**Contexto:** Dar uma segunda chance a quem não aceitou o template de manhã.

## Entradas
- `status`, `template`, `enviadoEm`, `contactId`, `phone`, `serviceId`

## Condições críticas
- Horário: seg–sex 13:20.
- Só status `AGUARDANDO` e ainda não reenviado.
- 1º envio há mais de 60 min e menos de 72 h.
- Um template por contato.
- Respeita a regra do chamado ocupado.

## Saída
- Template reenviado e marcado na coluna `template`.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F2-3 Automações agendadas]]
**📜 Histórico:** não registrado

---
fluxo: Central Líder
regra: Limpeza diária
versao_criada: v4
versao_fluxo: v14
nos: ["Separar dias anteriores", "Arquivar no HISTORICO_PEDIDOS", "Apagar dias anteriores", "Apagar eventos antigos"]
atualizado: 2026-11-12
tags: ["regra-negocio"]
---
# Regra - Limpeza diária

**Contexto:** A AGUARDANDO_ENTREGA passou a guardar só os pedidos do dia; o histórico vai para a HISTORICO_PEDIDOS.

## Entradas
- `createdAt` da linha (fuso America/Sao_Paulo)

## Condições críticas
- Linha criada antes de hoje → arquivada na HISTORICO_PEDIDOS e apagada.
- Linha de hoje → mantida (o fluxo pode rodar mais de uma vez no dia).
- Linha sem data → mantida (não arrisca apagar).
- v24: linha em `PENDENTE_RESPOSTA_TARDIA` → mantida até o consultor decidir.
- Pedido `AGRUPADO` é arquivado com o status final do pedido principal (v12).

## Saída
- AGUARDANDO_ENTREGA só com pedidos do dia; eventos antigos da FLUXO_STATUS apagados.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F1-1 Coleta e validação]]
**📜 Histórico:** [[v4 HISTORICO_PEDIDOS]]

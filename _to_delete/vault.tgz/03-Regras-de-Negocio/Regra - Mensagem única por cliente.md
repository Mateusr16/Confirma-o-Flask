---
fluxo: Central Líder
regra: Mensagem única por cliente
versao_criada: v12
versao_fluxo: v14
nos: ["Agrupar pedidos do mesmo cliente", "Registrar Revisão", "Expandir adiamento (grupo)", "Itens do registro (consultor)", "Normalizar Categoria", "Filtrar sem retorno elegível"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Mensagem única por cliente

**Contexto:** Cliente com 2 pedidos recebeu duas mensagens seguidas, e a resposta só seria aplicada a um dos pedidos (caso de 10/11, pedidos 210324 e 210325).

## Entradas
- `contactId` do DigiSac
- pedidos prontos para confirmar na mesma execução

## Condições críticas
- Mesmo contato com 2+ pedidos na mesma execução → 1 template e 1 mensagem.
- Principal = pedido de menor número (leva `pedidosGrupo` no `dadosPedido`); os outros ficam `AGRUPADO` com `agrupadoEm` = principal.
- Não agrupa: bloqueados, 1ª confirmação de planejados, resposta tardia, pedidos sem itens/datas legíveis.
- A resposta do cliente vale para todos os pedidos do grupo (planilha, intranet, adiamento, registro do consultor, sem retorno).

## Saída
- Mesma data: "A previsão de entrega dos seus pedidos *A* e *B* é *dd/mm*", com os produtos de cada pedido.
- Datas diferentes ou entrega parcial: um bloco 📦 por pedido, com 📅 cada data, e a pergunta no plural.
- Painel: 1 cartão "Pedidos 11-A + 11-B" na Revisão; o AGRUPADO acompanha o status do principal.

## Como foi testada
- `testes_v12/teste_agrupamento.js`: 60/60 OK; regressão idêntica à v11 para pedido sozinho; painel com 3 grupos 10/10 OK. Teste real pendente. Limitações: só agrupa pedidos da mesma execução; "Não enviar" vale para o grupo inteiro.

## Ligações
**⬅️ Aplicada em:** [[F1-3 Histórico e mensagem]] · [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]] · [[F2-3 Automações agendadas]] · [[Painel Central Líder]]
**📜 Histórico:** [[v12 MENSAGEM_UNICA]]

---
fluxo: Central Líder
regra: Pedido cancelado ou entregue
versao_criada: não registrado
versao_fluxo: v14
nos: ["Pedido cancelado?", "Marcar Cancelado Data Table", "Sheet – Pedido Cancelado", "entrega já realizada?", "Marcar Pedido Entregue", "Sheet – Já Faturado", "Send an Email1"]
atualizado: 2026-11-10
tags: ["regra-negocio"]
---
# Regra - Pedido cancelado ou entregue

**Contexto:** Pedido cancelado ou já entregue não deve receber mensagem de confirmação.

## Entradas
- situação do pedido na intranet (lojas.php)
- entregas por produto (situacao_pedidos.php)

## Condições críticas
- Cancelado → marca na tabela e na planilha; não segue.
- Entrega já realizada → marca entregue, planilha "já faturado" e e-mail à expedição; não segue.
- Entrega parcial → confere produto a produto.

## Saída
- Pedido fora da fila de confirmação, com o motivo registrado.

## Como foi testada
- não registrado.

## Ligações
**⬅️ Aplicada em:** [[F1-1 Coleta e validação]]
**📜 Histórico:** não registrado

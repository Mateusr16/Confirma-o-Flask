---
fluxo: Central Líder
regra: Classificação da resposta do cliente
versao_criada: não registrado
versao_fluxo: v26
nos: ["Basic LLM Chain", "Fora da regra? (1ª resposta)", "IA - Buscar resposta na base (1ª resposta)", "Normalizar Categoria", "Tem resposta fixa?"]
atualizado: 2026-11-12
tags: ["regra-negocio"]
---
# Regra - Classificação da resposta do cliente

**Contexto:** A IA classifica a resposta do cliente; o código aplica as regras por cima para não responder errado.

## Entradas
- texto do cliente (mensagens agrupadas)
- `confianca` da IA (0 a 1)

## Condições críticas
- Categorias: `ACEITA`, `ACEITA_PEDE_ADIANTAR`, `PEDE_ADIAR`, `DUVIDA_ADIAMENTO`, `NAO_ACEITA`, `ACEITA_CONTATO_RESPONSAVEL`, `RECUSA_CONTATO_RESPONSAVEL`, `OUTRO`.
- Confiança < 0,5 → `OUTRO` (um atendente olha).
- v26: a categoria trata só da parte sobre a data. A IA também devolve `foraDaRegra` e `assuntoFora`: qualquer assunto que as regras não cobrem (itens faltando, pedido já pronto/em exposição, recusa da taxa, montagem, endereço...), mesmo junto com "ok". Com `foraDaRegra`: base de conhecimento primeiro; base sabe → responde (confirmou também → agradece e registra); base não sabe → `OUTRO` (`FORA_DA_REGRA`), sem resposta e sem gravar.
- v26: depois do registro, ver [[Regra - Registro único do contato]].
- Data pedida igual à prevista → `ACEITA`; anterior à prevista → `NAO_ACEITA`.
- Pedido de antecipação não é atendido por este canal.

## Saída
- `ACEITA` → `CONCLUIDO`: "Perfeito, obrigado pela confirmação! Qualquer novidade, avisamos por aqui."
- `PEDE_ADIAR` → `DATA_ENVIADA` (ver regra de adiamento)
- `ACEITA_CONTATO_RESPONSAVEL` → `ESCALADO`
- `OUTRO` → `AGUARDANDO_CONSULTOR`

## Como foi testada
- 10 cenários em Node na v10 (inclui ACEITA e NAO_ACEITA): 10/10 OK.
- v26: `testes_v26/teste_registro_unico.js` 91/91 OK (casos Guilherme e Danielle de 12/11; 12 respostas normais idênticas à v25).

## Ligações
**⬅️ Aplicada em:** [[F2-1 Respostas do cliente]] · [[F2-2 Dúvidas e consultor]]
**📜 Histórico:** [[v10 AVISO_ARMAZENAGEM]] · [[v26 TRAVA_REGISTRO_UNICO]]

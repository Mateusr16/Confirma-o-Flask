---
fluxo: Central Líder
tipo: teste
atualizado: 2026-11-12
tags: [teste]
---
# Testes registrados por versão

Resumo das fichas do diário. Os scripts de teste ficam em `Claude outputs/testes_vNN/`. **Simulado** = código executado fora do n8n (Node/Python/Chrome). **Real** = execução no n8n.

| Versão | Simulado | Real |
|---|---|---|
| [[v26 TRAVA_REGISTRO_UNICO]] | `testes_v26/teste_registro_unico.js` 91/91 OK; regressão igual à v25 | pendente (97680) |
| [[v24 VARREDURA_TARDIA]] | `testes_v24/teste_varredura_tardia.js` 75/75 OK (reproduz na v23 o "Sim" de 11/11 perdido); regressão recomeço 68/68, CPF 10/10, lembrete 42/42, agrupamento 60/60, anti-repetição 39/41 e encerramento ocupado 41/42 (só as checagens de "nós idênticos à versão anterior") | pendente (varredura com o caso da Sarah) |
| [[v23 OCUPADO_SEM_RETORNO]] | `testes_v23/teste_encerramento_ocupado.js` 42/42 OK | pendente (1º encerramento real) |
| [[v21 ANTI_REPETICAO]] | `testes_v21/teste_anti_repeticao.js` 41/41 OK (reproduz o erro na v20; caso de 11/11: 1 resposta em vez de 5); regressão recomeço 68/68, CPF 10/10, lembrete 42/42 | pendente (97680: mesma resposta 2 vezes) |
| [[v20 RECOMECO_CONSULTA_CPF]] | `testes_v20/teste_recomeco.js` 68/68 OK; `teste_cpf_v20.js` 10/10 (página real do 210459); painel 26/26; regressão outlet 33/33, lembrete 42/42 | pendente (11-210588 pela tela Consultas da IA) |
| [[v18 RECOMECAR_PEDIDO]] | `testes_v18/teste_recomeco.js` 53/53 OK; painel `teste_painel_v18.py` 16/16; regressão outlet 33/33, lembrete 42/42, tela v16 | pendente (11-210588) |
| [[v17 OUTLET_CONFIRMADO]] | `testes_v17/teste_outlet_v17.js` 33/33 OK | pendente |
| [[v16 TELA_PROGRESSO]] | `testes_v16/teste_tela.js` 19/19 OK | pendente |
| [[v15 VIDEO_PLANEJADOS]] | `testes_v15/teste_video.js` 29/29 OK | leitura do vídeo no n8n OK, sem envio |
| [[v14 LEMBRETE_13H]] | `testes_v14/teste_lembrete.js` 42/42 OK; regressão outlet 23/23 | pendente (97680) |
| [[v13 OUTLET]] | `testes_v13/teste_outlet.js` 23/23 OK; v12 60/60 | pendente (11-209534) |
| [[v12 MENSAGEM_UNICA]] | `testes_v12/teste_agrupamento.js` 60/60 OK; painel 10/10 | pendente (cliente com 2 pedidos) |
| [[v11 DASHBOARD_CONTAGEM]] | contagem 9/9 OK; painel com 54 pedidos no Chrome | pendente |
| [[v10 AVISO_ARMAZENAGEM]] | 10 cenários em Node, 10/10 OK | pendente |
| [[v9 EDITAR_MENSAGEM]] | 32 + 7 testes OK; painel no Chrome | pendente |
| [[v8 RESPOSTA_TARDIA]] | 32 testes OK | 09/11: não detectou o caso (mensagem de 06/11, anterior ao início da gravação) |
| [[v7 CHAMADO_OCUPADO]] | não registrado | não registrado |
| v4 a v6 | não registrado | não registrado |

## Ligações
**🧪 Ferramenta:** [[Teste - Reset do pedido 97680]]

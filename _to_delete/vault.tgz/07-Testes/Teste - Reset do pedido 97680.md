---
fluxo: Central Líder
tipo: teste
resultado: ferramenta
atualizado: 2026-11-10
tags: [teste]
---
# Teste - Reset do pedido 97680

**Objetivo:** voltar o pedido 97680 para `DATA_ENVIADA` na [[AGUARDANDO_ENTREGA]] e repetir o teste da resposta do cliente.
**Arquivo:** `TESTE_Reset_Pedido_97680.json` (raiz e Projeto do claude.ai).
**Como rodar:** importar no n8n como workflow separado, ativar e abrir o webhook `teste-reset-97680`; o botão faz o reset.
**O que esperar:** só o pedido 97680 muda; nenhum outro é tocado.
**Tipo:** ferramenta de teste **real** (age na tabela de produção).

Workflow independente do fluxo principal; pode ser apagado sem afetar nada.

## Ligações
**🗄️ Grava:** [[AGUARDANDO_ENTREGA]] · **🧪 Usado em:** [[v8 RESPOSTA_TARDIA]]
